#ifndef PCA_PRUNE_H
#define PCA_PRUNE_H

#include <stdint.h>

/* =================== CONFIG =================== */
#define BATCH_M 60
#define N_VARS  6
#define MAX_KEEP_BINS 8

int pca_prune_get_current_sample_count(void);

/* Init PCA module */
void pca_prune_init(void);

/* Feed one sample of size N_VARS */
void pca_prune_feed_sample(const float sample[N_VARS]);

/* Try running PCA (returns 1 when run performed) */
int pca_prune_maybe_run_and_report(void);

/* Retrieve serialized payload pointer + length */
void pca_prune_get_serialized_payload(const uint8_t **ptr, uint16_t *len);

/* ================================================
   NEW: Tell PCA module the timestamp for the FIRST sample.
   These 8 bytes will be serialized along with PCAP payload.

   year_off: last two digits (e.g. 25 for 2025)
   month, day, hour, min, sec: natural values
   period_ms: sampling period in milliseconds between samples
   (useful for HES to compute timestamps for subsequent samples)
   ================================================ */
void pca_prune_set_start_timestamp(uint8_t year_off, uint8_t month, uint8_t day,
                                   uint8_t hour, uint8_t min, uint8_t sec,
                                   uint16_t period_ms);

#endif









//#ifndef PCA_PRUNE_H
//#define PCA_PRUNE_H
//
//#include <stdint.h>
//
///* Keep these consistent with your main project */
//#ifndef N_VARS
//#define N_VARS 6   /* current, voltage, active, apparent, pf, freq */
//#endif
//
//#ifndef BATCH_M
//#define BATCH_M 60
//#endif
//
///* Public API - used by main.c */
//void pca_prune_init(void);
//void pca_prune_feed_sample(const float sample[N_VARS]);
//
///* Run pruning when enough samples accumulated. If run, it prints report via dbg_print()
//   and resets the internal batch. Returns 1 if run, 0 otherwise. */
//int pca_prune_maybe_run_and_report(void);
///* existing pca_prune.h content ... */
//
///* After the existing API declarations, add: */
///**
// * Get a pointer to the last serialized pruned payload and its length.
// * The payload is valid until next PCA run. Caller must not free pointer.
// *
// * Payload format (binary):
// *  0..3   : ASCII 'P','R','U','N' (4 bytes)
// *  4      : version (uint8_t) = 1
// *  5      : n_vars (uint8_t)
// *  6..7   : batch_m (uint16_t, little-endian)
// *  8..11  : scale (float32) -- quantization scale used for int16 PC1 values
// *  then   : eigvec (n_vars * float32)
// *  then   : mean  (n_vars * float32)
// *  then   : int16_t pc1[batch_m] (quantized principal component samples)
// *
// * The HES reconstructs PC1 by: pc1[i] = (float)int16_pc1[i] / scale
// * Then per-sample: reconstructed_sample_vector = mean + pc1[i] * eigvec
// */
//void pca_prune_get_serialized_payload(const uint8_t **ptr, uint16_t *len);
//
//#endif /* PCA_PRUNE_H */
