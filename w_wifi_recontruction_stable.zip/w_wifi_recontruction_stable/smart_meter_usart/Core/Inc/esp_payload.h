/*
 * esp_payload.h
 *
 *  Created on: Nov 10, 2025
 *      Author: IOT_IIT
 */
#ifndef ESP_PAYLOAD_H
#define ESP_PAYLOAD_H

#include <stdint.h>

/* Build payload used by HES (must match hes_v1.py)
 * Returns length filled into buf, or -1 on error.
 */
int build_pruned_payload(uint8_t *buf, int buf_sz,
                         uint16_t batch_id, uint32_t timestamp,
                         uint8_t sample_count, uint8_t n_vars,
                         const float means[], const float eigvec[],
                         int n_bins, const uint8_t bins_idx[],
                         const int16_t qre[], const int16_t qim[],
                         float scale);

#endif /* ESP_PAYLOAD_H */
