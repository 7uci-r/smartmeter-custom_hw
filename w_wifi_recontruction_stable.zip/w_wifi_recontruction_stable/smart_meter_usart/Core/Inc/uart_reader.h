#ifndef UART_READER_H
#define UART_READER_H

#include <stdint.h>
#include <stddef.h>
#include "stm32f4xx_hal.h"

/* === UART Reader Public API === */

/**
 * @brief Initialize UART Reader with DMA and IDLE line interrupt.
 * @param huart Pointer to UART handle (e.g., &huart2)
 * @param hdma  Pointer to DMA handle (e.g., &hdma_usart2_rx)
 * @return HAL_OK on success, error code otherwise.
 */
HAL_StatusTypeDef uart_reader_init(UART_HandleTypeDef *huart, DMA_HandleTypeDef *hdma);

/**
 * @brief Start DMA reception manually if needed (safe restart).
 * @return HAL_OK on success, HAL_ERROR or HAL_BUSY otherwise.
 */
HAL_StatusTypeDef uart_reader_start_dma(void);

/**
 * @brief Handle UART IDLE interrupt — swap buffers and mark frame ready.
 * @param huart UART handle that triggered the IDLE interrupt.
 */
void uart_reader_on_idle(UART_HandleTypeDef *huart);

/* === Frame Definitions === */
#define FRAME_MARKER0   'T'
#define FRAME_MARKER1   'H'
#define FRAME_MARKER2   'D'
#define FRAME_MARKER3   'C'
#define PAYLOAD_LEN     39
#define FRAME_LEN       (4 + 1 + PAYLOAD_LEN + 2)  /* 46 bytes total (THDC + type + payload + CRC) */

/* === Frame Consumer API === */

/**
 * @brief Process DMA buffer manually (optional if not using IDLE interrupt).
 */
void uart_reader_process_dma_buffer(void);

/**
 * @brief Check if a full valid frame is available to read.
 * @return 1 if frame available, 0 otherwise.
 */
int uart_reader_frame_available(void);

/**
 * @brief Get and consume the latest available frame payload.
 * @param out_payload Array of length PAYLOAD_LEN to receive the data.
 */
void uart_reader_get_payload(uint8_t out_payload[PAYLOAD_LEN]);

/**
 * @brief Print last received raw frame bytes in HEX (debug helper).
 */
void uart_reader_print_last_frame_hex(void);

#endif /* UART_READER_H */
