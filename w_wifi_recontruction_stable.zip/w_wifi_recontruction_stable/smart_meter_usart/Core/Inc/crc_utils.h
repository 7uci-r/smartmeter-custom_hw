/*
 * crc_utils.h
 *
 *  Created on: Nov 10, 2025
 *      Author: IOT_IIT
 */
#ifndef CRC_UTILS_H
#define CRC_UTILS_H

#include <stdint.h>
#include <stddef.h>

/**
 * @brief Compute Modbus-style CRC16 (polynomial 0xA001, LSB first).
 * @param data Pointer to input buffer
 * @param length Number of bytes to process
 * @return 16-bit CRC value
 */
uint16_t modbus_crc16(const uint8_t *data, size_t length);

#endif /* CRC_UTILS_H */
