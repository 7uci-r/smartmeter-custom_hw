#ifndef DEBUG_LOG_H
#define DEBUG_LOG_H

#include <stdint.h>

typedef enum {
    LOG_ERROR = 0,
    LOG_WARN  = 1,
    LOG_INFO  = 2,
    LOG_DEBUG = 3
} log_level_t;

/* Init logger */
void debug_init(void);

/* Set verbosity */
void debug_set_level(log_level_t level);

/* Enable / disable machine mode (plain CSV output) */
void debug_set_machine_mode(int enable);

/* Log function */
void debug_log(log_level_t level, const char *fmt, ...);

/*
 * VERY IMPORTANT:
 * This is the TX-complete callback that MUST be called from:
 *
 *     HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
 *
 */
void debug_log_tx_complete_cb(void *huart_ptr);

#endif
