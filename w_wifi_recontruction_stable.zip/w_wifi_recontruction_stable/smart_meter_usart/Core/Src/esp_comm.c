/*
 * esp_comm.c  (PRODUCTION-READY, PERSISTENT TCP)
 *
 * Robust ESP-01 AT wrapper for STM32 HAL (UART5).
 *
 * Assumes:
 *   - extern UART_HandleTypeDef huart5; (ESP UART)
 *   - extern UART_HandleTypeDef huart3; (debug)
 *   - extern void dbg_print(const char *fmt, ...);
 *
 * Uses blocking HAL UART calls consistent with your setup.
 */

#include "esp_comm.h"
#include "main.h"
#include "usart.h"
#include "gpio.h"

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#ifndef ESP_DEFAULT_TIMEOUT
#define ESP_DEFAULT_TIMEOUT     8000U   /* General operations (ms) */
#endif
#ifndef ESP_PROMPT_TIMEOUT
#define ESP_PROMPT_TIMEOUT      5000U   /* Waiting for '>' prompt (ms) */
#endif
#ifndef ESP_SEND_TIMEOUT
#define ESP_SEND_TIMEOUT        12000U  /* Sending payload (ms) */
#endif
#ifndef ESP_IDLE_GAP
#define ESP_IDLE_GAP            200U    /* Idle gap for esp_read_resp (ms) */
#endif

/* Small delay after '>' before sending payload for stability */
#ifndef ESP_PROMPT_DELAY_MS
#define ESP_PROMPT_DELAY_MS     60U
#endif

/* Retries */
#ifndef ESP_CIPSTART_RETRIES
#define ESP_CIPSTART_RETRIES    2
#endif
#ifndef ESP_CIPSEND_RETRIES
#define ESP_CIPSEND_RETRIES     2
#endif

/* UART used for ESP */
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart3;

/* dbg_print provided by main.c */
extern void dbg_print(const char *fmt, ...);

#define ESP_UART_HANDLE huart5

/* Module persistent state */
static bool esp_tcp_persistent_connected = false;
static char esp_tcp_ip[32] = {0};
static int  esp_tcp_port = 0;

/* =========================================
   Low-level helpers
   ========================================= */

/* drain any bytes currently present on UART RX (non-blocking loop) */
static void esp_uart_flush(void)
{
    uint8_t tmp;
    uint32_t drained = 0;
    uint32_t t0 = HAL_GetTick();
    /* Read until no more bytes arrive for a short idle window */
    while (1) {
        HAL_StatusTypeDef r = HAL_UART_Receive(&ESP_UART_HANDLE, &tmp, 1, 10);
        if (r == HAL_OK) {
            drained++;
            /* continue draining */
            t0 = HAL_GetTick();
            continue;
        }
        if ((HAL_GetTick() - t0) >= 50) break;
    }
    if (drained) dbg_print("[ESP][FLUSH] drained %lu bytes\r\n", (unsigned long)drained);
}

/* Read response with idle detection. Returns number of bytes stored (NUL-terminated). */
static int esp_read_resp(char *buf, int maxlen, uint32_t timeout_ms, uint32_t idle_ms)
{
    if (!buf || maxlen < 2) return 0;

    uint32_t start = HAL_GetTick();
    uint32_t last  = start;
    int idx = 0;

    while ((HAL_GetTick() - start) < timeout_ms) {
        uint8_t ch;
        HAL_StatusTypeDef r = HAL_UART_Receive(&ESP_UART_HANDLE, &ch, 1, 30);
        if (r == HAL_OK) {
            if (idx < (maxlen - 1)) buf[idx++] = (char)ch;
            last = HAL_GetTick();
        } else {
            if ((HAL_GetTick() - last) >= idle_ms) break;
        }
    }

    if (idx >= maxlen) idx = maxlen - 1;
    buf[idx] = '\0';
    return idx;
}

/* send raw string command (includes trailing CRLF in the caller) */
static bool esp_send_raw(const char *cmd, uint32_t timeout_ms)
{
    if (!cmd) return false;
    HAL_StatusTypeDef tx = HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)cmd, (uint16_t)strlen(cmd), timeout_ms);
    if (tx != HAL_OK) {
        dbg_print("[ESP][TXERR] HAL_UART_Transmit rc=%d for: %s\r\n", (int)tx, cmd);
        return false;
    }
    return true;
}

/* send AT and print response (best-effort) */
bool esp_send_at_and_print(const char *cmd, uint32_t timeout_ms)
{
    char resp[512];
    dbg_print("[ESP SEND] %s", cmd);
    if (!esp_send_raw(cmd, 2000)) {
        dbg_print("[ESP] TX fail\r\n");
        return false;
    }
    int got = esp_read_resp(resp, sizeof(resp), timeout_ms, ESP_IDLE_GAP);
    if (got > 0) {
        dbg_print("[ESP RAW] %s\r\n", resp);
        return true;
    }
    dbg_print("[ESP RAW] <timeout>\r\n");
    return false;
}

/* Send command and check if 'expect' appears in response */
static bool esp_send_cmd_expect_print(const char *cmd, const char *expect, uint32_t timeout_ms)
{
    char resp[512];
    if (cmd) {
        dbg_print("[ESP SEND] %s", cmd);
        if (!esp_send_raw(cmd, 2000)) {
            dbg_print("[ESP] TX fail\r\n");
            return false;
        }
    }
    int got = esp_read_resp(resp, sizeof(resp), timeout_ms, ESP_IDLE_GAP);
    if (got > 0) {
        dbg_print("[ESP RAW] %s\r\n", resp);
        if (!expect) return true;
        return strstr(resp, expect) != NULL;
    }
    dbg_print("[ESP RAW] <timeout>\r\n");
    return false;
}

/* Soft recover - send ESC, a quick AT and a pause, attempt to re-sync */
static void esp_soft_recover(void)
{
    dbg_print("[ESP][RECOVER] soft recover\r\n");
    uint8_t esc = 0x1B;
    HAL_UART_Transmit(&ESP_UART_HANDLE, &esc, 1, 100);
    HAL_Delay(30);
    HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)"AT\r\n", 4, 200);
    HAL_Delay(120);
    esp_uart_flush();
}

/* =========================================================
   Public functions
   ========================================================= */

/* Basic module check */
bool esp_check_module(uint32_t timeout_ms)
{
    dbg_print("[ESP CHECK] AT\r\n");
    esp_send_at_and_print("AT\r\n", timeout_ms);
    dbg_print("[ESP CHECK] AT+GMR\r\n");
    esp_send_at_and_print("AT+GMR\r\n", timeout_ms);
    return true;
}

/* Robust WiFi join (verbose) */
bool esp_init_wifi_verbose(const char *ssid, const char *password, uint32_t timeout_ms)
{
    char cmd[256];
    char resp[512];

    dbg_print("[ESP WIFI] init: echo off, reset, set mode, join\r\n");

    /* attempt to kill any junk first */
    esp_uart_flush();

    /* disable echo */
    esp_send_cmd_expect_print("ATE0\r\n", "OK", 1500);

    /* reset (best-effort) */
    esp_send_raw("AT+RST\r\n", 1500);
    (void)esp_read_resp(resp, sizeof(resp), 3000, 250);

    /* station mode */
    esp_send_cmd_expect_print("AT+CWMODE=1\r\n", "OK", 1500);
    HAL_Delay(150);

    snprintf(cmd, sizeof(cmd), "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, password);

    const int max_connect_attempts = 6;
    uint32_t attempt_delay = 800U;

    for (int attempt = 1; attempt <= max_connect_attempts; ++attempt) {
        dbg_print("[ESP WIFI] CWJAP attempt %d/%d\r\n", attempt, max_connect_attempts);

        if (!esp_send_raw(cmd, 2000)) {
            dbg_print("[ESP WIFI] TX failed for CWJAP\r\n");
            HAL_Delay(attempt_delay);
            attempt_delay *= 2;
            continue;
        }

        /* Wait for response; tolerate busy messages */
        int got = esp_read_resp(resp, sizeof(resp), timeout_ms + (attempt * 1000U), 400);

        if (got > 0) {
            dbg_print("[ESP RAW] %s\r\n", resp);

            if (strstr(resp, "busy") || strstr(resp, "busy p")) {
                dbg_print("[ESP WIFI] module busy; wait 1500ms then reread\r\n");
                HAL_Delay(1500);
                (void)esp_read_resp(resp, sizeof(resp), 2000, 300);
                dbg_print("[ESP RAW after wait] %s\r\n", resp);
            }

            if (strstr(resp, "WIFI CONNECTED") || strstr(resp, "WIFI GOT IP") || strstr(resp, "WIFI ")) {
                dbg_print("[ESP WIFI] joined (WIFI line found)\r\n");
                return true;
            }

            if (strstr(resp, "OK") && (strstr(resp, "WIFI") == NULL)) {
                dbg_print("[ESP WIFI] got OK but no WIFI line; extra wait 2000ms\r\n");
                (void)esp_read_resp(resp, sizeof(resp), 2000, 300);
                if (strstr(resp, "WIFI CONNECTED") || strstr(resp, "WIFI GOT IP") || strstr(resp, "WIFI "))
                    return true;
            }
        } else {
            dbg_print("[ESP WIFI] no response to CWJAP (attempt %d)\r\n", attempt);
        }

        if (strstr(resp, "FAIL") || strstr(resp, "ERROR")) {
            dbg_print("[ESP WIFI] FAIL/ERROR in response -> backoff %ums\r\n", attempt_delay);
            HAL_Delay(attempt_delay);
            attempt_delay *= 2;
            continue;
        }

        HAL_Delay(attempt_delay);
        attempt_delay *= 2;
    }

    dbg_print("[ESP WIFI] join attempts exhausted\r\n");
    return false;
}

/* One-shot TCP connect (compat) */
bool esp_tcp_connect_verbose(const char *ip, int port, uint32_t timeout_ms)
{
    char cmd[128];
    snprintf(cmd, sizeof(cmd), "AT+CIPSTART=\"TCP\",\"%s\",%d\r\n", ip, port);

    dbg_print("[ESP TCP] CIPSTART -> %s:%d\r\n", ip, port);

    /* flush prior junk */
    esp_uart_flush();

    if (esp_send_cmd_expect_print(cmd, "CONNECT", timeout_ms) ||
        esp_send_cmd_expect_print(NULL, "OK", timeout_ms))
    {
        dbg_print("[ESP TCP] CIPSTART OK\r\n");
        return true;
    }

    dbg_print("[ESP TCP] CIPSTART FAILED\r\n");
    return false;
}

/* One-shot TCP send (compat) */
bool esp_tcp_send_verbose(const uint8_t *data, uint16_t len, uint32_t timeout_ms)
{
    if (!data || len == 0) return false;

    char cmd[64];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%u\r\n", len);

    dbg_print("[ESP TCP] CIPSEND %u\r\n", (unsigned)len);
    esp_uart_flush();

    if (!esp_send_raw(cmd, 2000)) {
        dbg_print("[ESP TCP] failed to TX CIPSEND\r\n");
        return false;
    }

    char resp[512];
    int got = esp_read_resp(resp, sizeof(resp), ESP_PROMPT_TIMEOUT, 200);
    dbg_print("[ESP RAW] %s\r\n", resp);

    if (got <= 0) {
        dbg_print("[ESP TCP] No prompt after CIPSEND\r\n");
        esp_soft_recover();
        return false;
    }
    if (!strstr(resp, ">")) {
        if (strstr(resp, "link is not valid")) {
            dbg_print("[ESP TCP] link invalid -> CIPCLOSE\r\n");
            esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", 2000);
            HAL_Delay(100);
        }
        esp_soft_recover();
        return false;
    }

    HAL_Delay(ESP_PROMPT_DELAY_MS);

    HAL_StatusTypeDef tx = HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)data, len, ESP_SEND_TIMEOUT);
    if (tx != HAL_OK) {
        dbg_print("[ESP TCP] TX fail (%d)\r\n", (int)tx);
        esp_soft_recover();
        return false;
    }

    got = esp_read_resp(resp, sizeof(resp), timeout_ms, 250);
    dbg_print("[ESP RAW] %s\r\n", resp);

    if (got > 0 && strstr(resp, "SEND OK")) {
        dbg_print("[ESP TCP] SEND OK\r\n");
        return true;
    }

    dbg_print("[ESP TCP] SEND FAIL\r\n");
    esp_soft_recover();
    return false;
}

/* Close helper */
void esp_tcp_close_verbose(uint32_t timeout_ms)
{
    dbg_print("[ESP TCP] CIPCLOSE\r\n");
    esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", timeout_ms);
}

/* Persistent TCP: open once, reuse */
bool esp_tcp_open_persistent(const char *ip, int port, uint32_t timeout_ms)
{
    if (!ip) return false;

    /* If already connected to same endpoint, success */
    if (esp_tcp_persistent_connected &&
        strcmp(esp_tcp_ip, ip) == 0 && esp_tcp_port == port)
    {
        dbg_print("[ESP TCP PERSIST] already connected to %s:%d\r\n", ip, port);
        return true;
    }

    /* close existing if mismatched */
    if (esp_tcp_persistent_connected) {
        dbg_print("[ESP TCP PERSIST] closing stale persistent connection\r\n");
        esp_tcp_close_verbose(2000);
        esp_tcp_persistent_connected = false;
    }

    /* Try multiple attempts */
    for (int attempt = 0; attempt <= ESP_CIPSTART_RETRIES; ++attempt) {
        esp_uart_flush();
        char cmd[128];
        snprintf(cmd, sizeof(cmd), "AT+CIPSTART=\"TCP\",\"%s\",%d\r\n", ip, port);
        dbg_print("[ESP TCP PERSIST] Opening %s:%d (attempt %d)\r\n", ip, port, attempt+1);

        if (esp_send_cmd_expect_print(cmd, "CONNECT", timeout_ms) ||
            esp_send_cmd_expect_print(NULL, "OK", timeout_ms))
        {
            dbg_print("[ESP TCP PERSIST] CIPSTART OK\r\n");
            strncpy(esp_tcp_ip, ip, sizeof(esp_tcp_ip)-1);
            esp_tcp_port = port;
            esp_tcp_persistent_connected = true;
            return true;
        }

        dbg_print("[ESP TCP PERSIST] CIPSTART attempt %d failed\r\n", attempt+1);
        HAL_Delay(200 + attempt * 200);
        esp_soft_recover();
    }

    dbg_print("[ESP TCP PERSIST] CIPSTART FAILED after retries\r\n");
    esp_tcp_persistent_connected = false;
    return false;
}

/* Persistent send: auto-reopen once if needed; return true on SEND OK */
bool esp_tcp_send_persistent(const uint8_t *data, uint16_t len, uint32_t timeout_ms)
{
    if (!data || len == 0) return false;

    /* If not connected, try to open */
    if (!esp_tcp_persistent_connected) {
        dbg_print("[ESP TCP PERSIST] not connected -> attempting open to %s:%d\r\n",
                  esp_tcp_ip[0] ? esp_tcp_ip : "<unknown>", esp_tcp_port);
        if (!esp_tcp_open_persistent(esp_tcp_ip, esp_tcp_port, timeout_ms)) {
            dbg_print("[ESP TCP PERSIST] open failed, cannot send\r\n");
            return false;
        }
    }

    /* Try multiple CIPSEND attempts */
    for (int attempt = 0; attempt <= ESP_CIPSEND_RETRIES; ++attempt) {
        esp_uart_flush();
        char cmd[64];
        snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%u\r\n", (unsigned)len);
        dbg_print("[ESP TCP PERSIST] CIPSEND %u (attempt %d)\r\n", (unsigned)len, attempt+1);

        if (!esp_send_raw(cmd, 2000)) {
            dbg_print("[ESP TCP PERSIST] TX fail for CIPSEND cmd\r\n");
            esp_tcp_persistent_connected = false;
            return false;
        }

        char resp[512];
        int got = esp_read_resp(resp, sizeof(resp), ESP_PROMPT_TIMEOUT, 200);
        dbg_print("[ESP RAW] %s\r\n", resp);

        if (got <= 0 || !strstr(resp, ">")) {
            dbg_print("[ESP TCP PERSIST] No prompt or unexpected response\r\n");
            if (strstr(resp, "link is not valid") || strstr(resp, "ERROR") || strstr(resp, "CLOSED")) {
                dbg_print("[ESP TCP PERSIST] link invalid/closed -> cleaning up\r\n");
                esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", 2000);
            }
            esp_tcp_persistent_connected = false;
            esp_soft_recover();
            /* try reopen & retry if attempt < retries */
            if (attempt < ESP_CIPSEND_RETRIES) {
                dbg_print("[ESP TCP PERSIST] retrying open then CIPSEND\r\n");
                if (!esp_tcp_open_persistent(esp_tcp_ip, esp_tcp_port, timeout_ms)) {
                    dbg_print("[ESP TCP PERSIST] reopen failed\r\n");
                    return false;
                }
                continue;
            } else {
                return false;
            }
        }

        /* stability wait */
        HAL_Delay(ESP_PROMPT_DELAY_MS);

        /* send payload */
        HAL_StatusTypeDef tx = HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)data, len, ESP_SEND_TIMEOUT);
        if (tx != HAL_OK) {
            dbg_print("[ESP TCP PERSIST] payload TX error %d\r\n", (int)tx);
            esp_tcp_persistent_connected = false;
            esp_soft_recover();
            /* try reopen and retry if allowed */
            if (attempt < ESP_CIPSEND_RETRIES) {
                if (!esp_tcp_open_persistent(esp_tcp_ip, esp_tcp_port, timeout_ms)) return false;
                continue;
            }
            return false;
        }

        /* wait for SEND OK */
        got = esp_read_resp(resp, sizeof(resp), timeout_ms, 250);
        dbg_print("[ESP RAW] %s\r\n", resp);

        if (got > 0 && strstr(resp, "SEND OK")) {
            dbg_print("[ESP TCP PERSIST] SEND OK\r\n");
            return true;
        }

        dbg_print("[ESP TCP PERSIST] SEND FAIL -> clearing persistent flag\r\n");
        esp_tcp_persistent_connected = false;
        esp_soft_recover();

        /* try reopen & retry if allowed */
        if (attempt < ESP_CIPSEND_RETRIES) {
            dbg_print("[ESP TCP PERSIST] will attempt reopen and retry CIPSEND\r\n");
            if (!esp_tcp_open_persistent(esp_tcp_ip, esp_tcp_port, timeout_ms)) return false;
        } else {
            return false;
        }
    }

    return false;
}

/* Close persistent connection public function */
void esp_tcp_close_persistent(uint32_t timeout_ms)
{
    dbg_print("[ESP TCP PERSIST] Closing persistent connection\r\n");
    esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", timeout_ms);
    esp_tcp_persistent_connected = false;
    esp_tcp_ip[0] = 0;
    esp_tcp_port = 0;
    esp_uart_flush();
}

