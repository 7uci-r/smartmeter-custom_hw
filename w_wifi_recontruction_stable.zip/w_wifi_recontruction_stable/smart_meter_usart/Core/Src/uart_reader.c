/*
 * uart_reader.c
 * Robust UART DMA double-buffered reader for THDC frames with IDLE detection and CRC validation.
 */

#include "uart_reader.h"
#include "crc_utils.h"    /* must provide: uint16_t modbus_crc16(const uint8_t *buf, size_t len); */
#include "debug_log.h"
#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdint.h>
#include <stdio.h>  /* for snprintf */

/* Forward declaration for internal parser (must appear before any call) */
static void parse_and_validate_frame(uint8_t *buf, uint16_t len);

/* === Configuration === */
#define RX_BUF_SIZE   (2 * FRAME_LEN)   /* Double-buffer for safety */

/* === Internal static variables === */
static UART_HandleTypeDef *s_huart = NULL;
static DMA_HandleTypeDef  *s_hdma = NULL;

static uint8_t  rx_buf[RX_BUF_SIZE];
static uint8_t  frame_buf[FRAME_LEN];
static uint8_t  payload_buf[PAYLOAD_LEN];
static volatile int frame_ready = 0;

/* ================================================================
 * uart_reader_init
 * ================================================================ */
HAL_StatusTypeDef uart_reader_init(UART_HandleTypeDef *huart, DMA_HandleTypeDef *hdma)
{
    if (!huart) return HAL_ERROR;
    s_huart = huart;
    s_hdma  = hdma ? hdma : huart->hdmarx;

    if (!s_hdma) {
        debug_log(LOG_ERROR, "uart_reader_init: no hdmarx available");
        return HAL_ERROR;
    }

    /* Enable the UART IDLE interrupt so we can detect end-of-frame */
    __HAL_UART_ENABLE_IT(s_huart, UART_IT_IDLE);

    /* Start DMA reception on rx_buf */
    return uart_reader_start_dma();
}

/* ================================================================
 * uart_reader_start_dma
 * ================================================================ */
HAL_StatusTypeDef uart_reader_start_dma(void)
{
    if (!s_huart || !s_hdma) return HAL_ERROR;

    /* Stop any ongoing DMA to avoid conflicts, then restart */
    HAL_UART_DMAStop(s_huart);

    HAL_StatusTypeDef status = HAL_UART_Receive_DMA(s_huart, rx_buf, RX_BUF_SIZE);
    if (status != HAL_OK) {
        debug_log(LOG_ERROR, "UART DMA start failed: %d", (int)status);
        return status;
    }

    debug_log(LOG_INFO, "UART DMA started (%d bytes)", (int)RX_BUF_SIZE);
    return HAL_OK;
}

/* ================================================================
 * uart_reader_on_idle
 * should be called from the UART IRQ after clearing IDLE flag
 * ================================================================ */
void uart_reader_on_idle(UART_HandleTypeDef *huart)
{
    if (huart != s_huart) return;

    /* Compute how many bytes have been received so far */
    uint32_t rem = __HAL_DMA_GET_COUNTER(s_hdma);
    uint16_t bytes = (uint16_t)(RX_BUF_SIZE - rem);
    if (bytes == 0) return;

//    /* Copy up to FRAME_LEN bytes (we expect fixed-length frames) */
//    uint16_t copy_len = (bytes > FRAME_LEN) ? FRAME_LEN : bytes;
//    memcpy(frame_buf, rx_buf, copy_len);
    /* We only accept FULL FRAME_LEN bytes */
    if (bytes < FRAME_LEN) {
        /* discard partial */
        return;
    }

    memcpy(frame_buf, rx_buf, FRAME_LEN);

    /* Stop + restart DMA so rx_buf becomes fresh for next reception */
    /* Clear RX buffer completely BEFORE restarting DMA */
    memset(rx_buf, 0, RX_BUF_SIZE);

    /* Now restart DMA safely */
    HAL_UART_DMAStop(s_huart);
    uart_reader_start_dma();

    /* Parse and validate the just-received frame */
    parse_and_validate_frame(frame_buf, copy_len);
}

/* ================================================================
 * parse_and_validate_frame (internal)
 * ================================================================ */
static void parse_and_validate_frame(uint8_t *buf, uint16_t len)
{
    if (len < FRAME_LEN) {
        debug_log(LOG_WARN, "UART frame too short: %u", (unsigned)len);
        return;
    }

    /* header check */
    if (buf[0] != FRAME_MARKER0 || buf[1] != FRAME_MARKER1 ||
        buf[2] != FRAME_MARKER2 || buf[3] != FRAME_MARKER3) {
        debug_log(LOG_WARN, "UART invalid frame header");
        return;
    }

    /* CRC: last two bytes (network order) */
    uint16_t received_crc = (uint16_t)((buf[FRAME_LEN - 2] << 8) | buf[FRAME_LEN - 1]);
    uint16_t computed_crc = modbus_crc16(buf, (size_t)(FRAME_LEN - 2));

    if (received_crc != computed_crc) {
        debug_log(LOG_WARN, "UART CRC mismatch got=0x%04X expect=0x%04X", received_crc, computed_crc);
        return;
    }

    /* Extract payload (header 4 + type 1 = start at index 5) */
    memcpy(payload_buf, &buf[5], PAYLOAD_LEN);
    frame_ready = 1;

    debug_log(LOG_INFO, "UART valid frame received");

    /* After handling one frame, clear frame_buf fully */
    memset(frame_buf, 0, FRAME_LEN);

}

/* ================================================================
 * uart_reader_process_dma_buffer - optional fallback poll
 * ================================================================ */
void uart_reader_process_dma_buffer(void)
{
    if (!s_hdma) return;
    uint32_t rem = __HAL_DMA_GET_COUNTER(s_hdma);
    uint16_t bytes = (uint16_t)(RX_BUF_SIZE - rem);
    if (bytes > 0) {
        uint16_t copy_len = (bytes > FRAME_LEN) ? FRAME_LEN : bytes;
        memcpy(frame_buf, rx_buf, copy_len);
        parse_and_validate_frame(frame_buf, copy_len);
    }
}

/* ================================================================
 * uart_reader_frame_available / uart_reader_get_payload
 * ================================================================ */
int uart_reader_frame_available(void)
{
    return frame_ready;
}

void uart_reader_get_payload(uint8_t out_payload[PAYLOAD_LEN])
{
    if (!frame_ready) return;
    memcpy(out_payload, payload_buf, PAYLOAD_LEN);
    frame_ready = 0;
}

/* ================================================================
 * Debug helper
 * ================================================================ */
void uart_reader_print_last_frame_hex(void)
{
    char tmp[48];
    int pos = 0;
    for (int i = 0; i < FRAME_LEN && pos + 4 < (int)sizeof(tmp); ++i) {
        pos += snprintf(&tmp[pos], sizeof(tmp) - pos, "%02X ", frame_buf[i]);
    }
    debug_log(LOG_DEBUG, "UART last frame: %s", tmp);
}
