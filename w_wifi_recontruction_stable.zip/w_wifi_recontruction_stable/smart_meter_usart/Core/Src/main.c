/* Core/Src/main.c - WiFi-enabled main (PERSISTENT TCP mode)
   Compatible with updated pca_prune.c and pca_prune.h
*/

#include "main.h"
#include "dma.h"
#include "usart.h"
#include "usb_otg.h"
#include "gpio.h"
#include "fft_utils.h"

#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <math.h>

#include "pca_prune.h"
#include "esp_comm.h"

#define HAVE_PCA_PRUNE 1

/* ====== THDC FRAME FORMAT ====== */
#define FRAME_TOTAL_LEN   46
#define FRAME_PAYLOAD_LEN 39
#define FRAME_HEADER0 'T'
#define FRAME_HEADER1 'H'
#define FRAME_HEADER2 'D'
#define FRAME_HEADER3 'C'

#ifndef RX_DMA_BUF_LEN
#define RX_DMA_BUF_LEN 128
#endif

extern volatile uint8_t rx_dma_buf[RX_DMA_BUF_LEN];

/* ===== FORWARD DECL ===== */
void SystemClock_Config(void);

/* ===== THDC PARSER STATE ===== */
static uint8_t frame_buf[FRAME_TOTAL_LEN];
static size_t frame_idx = 0;
static int parser_state = 0;
static uint16_t dma_last_pos = 0;

static volatile float parsed_voltage = 0.0f;
static volatile float parsed_current = 0.0f;
static volatile float parsed_frequency = 0.0f;
static volatile float parsed_apparent = 0.0f;
static volatile float parsed_active = 0.0f;
static volatile float parsed_pf = 0.0f;
static volatile char  parsed_pfSign = ' ';

static volatile uint8_t parsed_day = 0;
static volatile uint8_t parsed_month = 0;
static volatile uint8_t parsed_year_off = 0;
static volatile uint8_t parsed_hour = 0;
static volatile uint8_t parsed_minute = 0;
static volatile uint8_t parsed_second = 0;

static volatile uint8_t frame_ready_flag = 0;

/* ===== DEBUG PRINT ===== */
void dbg_print(const char *fmt, ...)
{
    char tmp[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n > 0) {
        uint16_t len = (uint16_t)((n < sizeof(tmp)) ? n : sizeof(tmp) - 1);
        HAL_UART_Transmit(&huart3, (uint8_t*)tmp, len, HAL_MAX_DELAY);
    }
}

/* ===== CRC + READ HELPERS ===== */
static uint16_t crc16_modbus(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t pos = 0; pos < len; pos++) {
        crc ^= data[pos];
        for (uint8_t i = 0; i < 8; i++) {
            if (crc & 1) crc = (crc >> 1) ^ 0xA001;
            else crc >>= 1;
        }
    }
    return crc;
}

static uint32_t read_u32_be(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) |
           ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8)  |
            (uint32_t)p[3];
}

static uint16_t read_u16_be(const uint8_t *p)
{
    return (uint16_t)((p[0] << 8) | p[1]);
}

/* ===== DMA PARSER ===== */
static void parser_feed_byte(uint8_t b)
{
    switch (parser_state)
    {
        case 0:
            if (b == FRAME_HEADER0) { frame_buf[0] = b; frame_idx = 1; parser_state = 1; }
            break;

        case 1:
            if (b == FRAME_HEADER1) { frame_buf[frame_idx++] = b; parser_state = 2; }
            else { parser_state = (b == FRAME_HEADER0) ? 1 : 0; frame_idx = parser_state ? 1 : 0; }
            break;

        case 2:
            if (b == FRAME_HEADER2) { frame_buf[frame_idx++] = b; parser_state = 3; }
            else { parser_state = (b == FRAME_HEADER0) ? 1 : 0; frame_idx = parser_state ? 1 : 0; }
            break;

        case 3:
            if (b == FRAME_HEADER3) { frame_buf[frame_idx++] = b; parser_state = 4; }
            else { parser_state = (b == FRAME_HEADER0) ? 1 : 0; frame_idx = parser_state ? 1 : 0; }
            break;

        case 4:
            frame_buf[frame_idx++] = b;
            if (b != FRAME_PAYLOAD_LEN) { parser_state = 0; frame_idx = 0; }
            else parser_state = 5;
            break;

        case 5:
            frame_buf[frame_idx++] = b;
            if (frame_idx >= FRAME_TOTAL_LEN)
            {
                uint16_t crc_calc = crc16_modbus(&frame_buf[5], FRAME_PAYLOAD_LEN);
                uint16_t crc_rx   = ((uint16_t)frame_buf[44] << 8) | frame_buf[45];

                if (crc_calc == crc_rx)
                {
                    const uint8_t *pl = &frame_buf[5];

                    parsed_voltage   = read_u32_be(&pl[0]) / 1000.0f;
                    parsed_current   = read_u32_be(&pl[4]) / 1000.0f;
                    parsed_active    = read_u32_be(&pl[8]);
                    parsed_apparent  = read_u32_be(&pl[16]);
                    parsed_pf        = read_u16_be(&pl[20]) / 100.0f;
                    parsed_pfSign    = (char)pl[22];
                    parsed_frequency = read_u16_be(&pl[23]) / 100.0f;

                    parsed_day       = pl[33];
                    parsed_month     = pl[34];
                    parsed_year_off  = pl[35];
                    parsed_hour      = pl[36];
                    parsed_minute    = pl[37];
                    parsed_second    = pl[38];

                    frame_ready_flag = 1;
                }

                parser_state = 0;
                frame_idx = 0;
            }
            break;

        default:
            parser_state = 0;
            frame_idx = 0;
            break;
    }
}

static void parser_poll_dma(void)
{
    if (huart2.hdmarx == NULL) return;

    uint16_t new_pos = (uint16_t)(RX_DMA_BUF_LEN - __HAL_DMA_GET_COUNTER(huart2.hdmarx));

    if (new_pos != dma_last_pos)
    {
        if (new_pos > dma_last_pos)
        {
            for (uint16_t i = dma_last_pos; i < new_pos; i++)
                parser_feed_byte(rx_dma_buf[i]);
        }
        else
        {
            for (uint16_t i = dma_last_pos; i < RX_DMA_BUF_LEN; i++)
                parser_feed_byte(rx_dma_buf[i]);
            for (uint16_t i = 0; i < new_pos; i++)
                parser_feed_byte(rx_dma_buf[i]);
        }
        dma_last_pos = new_pos;
    }
}

/* ===== MAIN ===== */

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_USART3_UART_Init();
    MX_USB_OTG_FS_PCD_Init();
    MX_USART2_UART_Init();
    MX_UART5_Init();

    dbg_print("[DIAG] Running ESP module check...\r\n");
    esp_check_module(1000);

    dbg_print("\r\n[BOOT] THDC + PCA + WiFi + RTC print active\r\n");

#ifdef HAVE_PCA_PRUNE
    pca_prune_init();
#endif

    /* Start DMA for meter UART2 */
    HAL_UART_Receive_DMA(&huart2, (uint8_t*)rx_dma_buf, RX_DMA_BUF_LEN);
    dma_last_pos = (uint16_t)(RX_DMA_BUF_LEN - __HAL_DMA_GET_COUNTER(huart2.hdmarx));
    dbg_print("DMA RX started (%u bytes)\r\n", RX_DMA_BUF_LEN);

    bool wifi_ready = false;
    bool tcp_persistent_open = false;

    const char *WIFI_SSID = "RM 1725";
    const char *WIFI_PASS = "877,2f3W";
    const char *HES_IP = "192.168.137.1";
    const int   HES_PORT = 5050;

    /* ===== Batch Timestamp Flag ===== */
    bool batch_new = true;

    uint32_t last_rtc_print_ms = 0;

    /* ===== Try WiFi Join ===== */
    if (esp_init_wifi_verbose(WIFI_SSID, WIFI_PASS, 10000))
    {
        dbg_print("[WIFI] joined SSID OK\r\n");
        wifi_ready = true;

        if (esp_tcp_open_persistent(HES_IP, HES_PORT, 8000))
        {
            dbg_print("[WIFI] persistent TCP open OK -> %s:%d\r\n", HES_IP, HES_PORT);
            tcp_persistent_open = true;
        }
        else
        {
            dbg_print("[WIFI] persistent TCP open FAILED\r\n");
            tcp_persistent_open = false;
        }
    }
    else
    {
        dbg_print("[WIFI] join failed at boot\r\n");
    }

    /* ===================== MAIN LOOP ===================== */
    while (1)
    {
        parser_poll_dma();
        uint32_t now = HAL_GetTick();

        /* RTC print every second */
        if (now - last_rtc_print_ms >= 1000)
        {
            last_rtc_print_ms = now;
            dbg_print("[RTC] %02u-%02u-20%02u %02u:%02u:%02u\r\n",
                parsed_day, parsed_month, parsed_year_off,
                parsed_hour, parsed_minute, parsed_second);
        }

        /* ---- FRAME PARSED ---- */
        if (frame_ready_flag)
        {
            frame_ready_flag = 0;

            float voltage  = parsed_voltage * 10.0f;
            float current  = parsed_current;
            float freq     = parsed_frequency * 10.0f;
            float apparent = parsed_apparent;
            float active   = parsed_active;
            float pf       = parsed_pf;

            dbg_print("[DATA] %02u-%02u-20%02u %02u:%02u:%02u | "
                      "V=%.2f I=%.3f P=%.1f PF=%c%.2f F=%.2f\r\n",
                      parsed_day, parsed_month, parsed_year_off,
                      parsed_hour, parsed_minute, parsed_second,
                      voltage, current, active, parsed_pfSign, pf, freq);

            /* ------ TIMESTAMP FOR FIRST SAMPLE OF BATCH ------ */
            if (batch_new)
            {
                pca_prune_set_start_timestamp(
                    parsed_year_off,
                    parsed_month,
                    parsed_day,
                    parsed_hour,
                    parsed_minute,
                    parsed_second,
                    1000   /* 1 second per sample */
                );
                batch_new = false;

                dbg_print("[PCA] start timestamp set: 20%02u-%02u-%02u %02u:%02u:%02u\r\n",
                    parsed_year_off, parsed_month, parsed_day,
                    parsed_hour, parsed_minute, parsed_second);
            }

            /* ------ PCA FEED SAMPLE ------ */
            float sample[N_VARS] = { current, voltage, active, apparent, pf, freq };
            pca_prune_feed_sample(sample);

            /* ------ PCA RUN ------ */
            if (pca_prune_maybe_run_and_report())
            {
                /* next frame is new batch */
                batch_new = true;

                const uint8_t *payload = NULL;
                uint16_t payload_len   = 0;
                pca_prune_get_serialized_payload(&payload, &payload_len);

                if (payload && payload_len > 0)
                {
                    dbg_print("[SEND] Prepared payload %u bytes - sending...\r\n", payload_len);

                    /* Ensure WiFi */
                    if (!wifi_ready)
                    {
                        dbg_print("[WIFI] retry join...\r\n");
                        if (esp_init_wifi_verbose(WIFI_SSID, WIFI_PASS, 10000))
                        {
                            wifi_ready = true;
                            dbg_print("[WIFI] join OK (retry)\r\n");
                        }
                    }

                    /* Ensure TCP */
                    if (wifi_ready && !tcp_persistent_open)
                    {
                        dbg_print("[TCP] opening persistent TCP...\r\n");
                        if (esp_tcp_open_persistent(HES_IP, HES_PORT, 8000))
                        {
                            tcp_persistent_open = true;
                            dbg_print("[TCP] persistent open OK\r\n");
                        }
                    }

                    /* Send */
                    if (wifi_ready && tcp_persistent_open)
                    {
                        if (esp_tcp_send_persistent(payload, payload_len, 8000))
                        {
                            dbg_print("[SEND] PCA payload sent OK (%u bytes)\r\n", payload_len);
                        }
                        else
                        {
                            dbg_print("[SEND] PCA send failed -> closing TCP\r\n");
                            esp_tcp_close_persistent(2000);
                            tcp_persistent_open = false;
                        }
                    }
                    else
                    {
                        dbg_print("[SEND] Skipped: WiFi/TCP not ready\r\n");
                    }
                }
                else
                {
                    dbg_print("[SEND] No payload after PCA run\r\n");
                }
            }
        }

        HAL_Delay(1);
    }
}

/* ===== Clock Config (unchanged) ===== */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_BYPASS;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM       = 8;
    RCC_OscInitStruct.PLL.PLLN       = 384;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV4;
    RCC_OscInitStruct.PLL.PLLQ       = 8;
    RCC_OscInitStruct.PLL.PLLR       = 2;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK |
                                  RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 |
                                  RCC_CLOCKTYPE_PCLK2;

    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}

