/*
 * crc_utils.c
 *
 *  Created on: Nov 10, 2025
 *      Author: IOT_IIT
 */


//#include "stdint.h"
//
//// Simple standard CRC-16 (Modbus-compatible) used for data integrity
//uint16_t crc16_modbus(const uint8_t *buf, uint16_t len)
//{
//    uint16_t crc = 0xFFFF;
//    for (uint16_t pos = 0; pos < len; pos++) {
//        crc ^= (uint16_t)buf[pos];
//        for (uint8_t i = 0; i < 8; i++) {
//            if (crc & 0x0001) {
//                crc >>= 1;
//                crc ^= 0xA001;
//            } else {
//                crc >>= 1;
//            }
//        }
//    }
//    return crc;
//}
#include "crc_utils.h"

/**
 * @brief Standard Modbus RTU CRC16 (poly = 0xA001)
 */
uint16_t modbus_crc16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 0x0001)
                crc = (crc >> 1) ^ 0xA001;
            else
                crc = crc >> 1;
        }
    }
    return crc;
}
