/*
 * DMA-based non-blocking debug logger.
 * Uses huart3 (extern). Matches debug_log.h API used above.
 */

#include "debug_log.h"
#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

/* CONFIG */
#define DBG_RING_SIZE        (16 * 1024u)
#define DBG_TMPBUF           256
#define DBG_DMA_CHUNK_MAX    512

extern UART_HandleTypeDef huart3; /* ensure defined in your usart.c */

static char dbg_ring[DBG_RING_SIZE];
static volatile uint32_t dbg_wp = 0;
static volatile uint32_t dbg_rp = 0;
static volatile uint8_t dma_tx_busy = 0;
static log_level_t current_level = LOG_INFO;
static volatile int machine_mode = 0;

static inline uint32_t ring_used(void) {
    if (dbg_wp >= dbg_rp) return dbg_wp - dbg_rp;
    return DBG_RING_SIZE - (dbg_rp - dbg_wp);
}
static inline uint32_t ring_free(void) {
    return (DBG_RING_SIZE - ring_used() - 1);
}
static inline void ring_push_bytes(const char *buf, uint32_t len) {
    for (uint32_t i = 0; i < len; i++) {
        uint32_t next = (dbg_wp + 1) % DBG_RING_SIZE;
        if (next == dbg_rp) return; /* full */
        dbg_ring[dbg_wp] = buf[i];
        dbg_wp = next;
    }
}

/* forward */
static void try_flush(void);

void debug_init(void) {
    dbg_wp = dbg_rp = 0;
    dma_tx_busy = 0;
}

void debug_set_level(log_level_t level) {
    current_level = level;
}

void debug_set_machine_mode(int enable) {
    machine_mode = enable ? 1 : 0;
}

void debug_log(log_level_t level, const char *fmt, ...) {
    if (level > current_level) return;

    char tmp[DBG_TMPBUF];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp)-1, fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if (n >= (int)sizeof(tmp)) n = sizeof(tmp) - 2;

    if (!machine_mode) {
        const char *tag =
                (level == LOG_ERROR) ? "ERR" :
                (level == LOG_WARN)  ? "WRN" :
                (level == LOG_INFO)  ? "INF" : "DBG";
        char pfx[16];
        int m = snprintf(pfx, sizeof(pfx), "[%s] ", tag);
        ring_push_bytes(pfx, (uint32_t)m);
    }

    ring_push_bytes(tmp, (uint32_t)n);
    ring_push_bytes("\r\n", 2);

    try_flush();
}

static void try_flush(void) {
    if (dma_tx_busy) return;
    uint32_t used = ring_used();
    if (used == 0) return;
    uint32_t rp = dbg_rp;
    uint32_t chunk;
    if (dbg_wp > rp) chunk = dbg_wp - rp;
    else chunk = DBG_RING_SIZE - rp;
    if (chunk > DBG_DMA_CHUNK_MAX) chunk = DBG_DMA_CHUNK_MAX;
    if (chunk == 0) return;
    dma_tx_busy = 1;
    if (HAL_UART_Transmit_DMA(&huart3, (uint8_t *)&dbg_ring[rp], (uint16_t)chunk) != HAL_OK) {
        dma_tx_busy = 0;
        return;
    }
    dbg_rp = (rp + chunk) % DBG_RING_SIZE;
}

/* This function MUST be called from HAL_UART_TxCpltCallback in your project:
 *
 * void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
 *     debug_log_tx_complete_cb((void*)huart);
 *     // ... other callbacks
 * }
 */
void debug_log_tx_complete_cb(void *huart_ptr) {
    if (huart_ptr != &huart3) return;
    dma_tx_busy = 0;
    try_flush();
}
