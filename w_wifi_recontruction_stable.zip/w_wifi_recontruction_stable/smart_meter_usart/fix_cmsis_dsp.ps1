# PowerShell script to clean and fix CMSIS-DSP source tree for STM32CubeIDE build
# Run this from: C:\Users\IOT_IIT\STM32CubeIDE\workspace_1.19.0\smart_meter_usart

$root = "C:\Users\IOT_IIT\STM32CubeIDE\workspace_1.19.0\smart_meter_usart"
$log = "$root\Debug\dsp_fix_log.txt"
$drivers = Join-Path $root "Drivers\CMSIS\DSP\Source"

"=== CMSIS-DSP Project Fix Log ===" | Out-File $log -Encoding utf8

# 1️⃣  Remove aggregate *.c files that only include other DSP sources
Get-ChildItem -Path $drivers -Recurse -Filter *.c | ForEach-Object {
    $content = Get-Content $_.FullName -Raw
    if ($content -match '#include\s+"arm_.*\.c"') {
        "Excluding aggregate file: $($_.FullName)" | Tee-Object -FilePath $log -Append
        $rel = $_.FullName.Replace("$root\", "")
        $exclFile = "$root\.exclude_from_build.txt"
        Add-Content $exclFile $rel
        attrib +h $_.FullName  # hide it so CubeIDE ignores it
    }
}

# 2️⃣  Check for bitreversal function mismatch
$bitrev = Get-ChildItem -Path $drivers -Recurse -Filter "arm_bitreversal.c" | Select-Object -First 1
if ($bitrev) {
    $content = Get-Content $bitrev.FullName -Raw
    if ($content -notmatch "arm_bitreversal_32") {
        "Warning: arm_bitreversal_32 not found in $($bitrev.FullName)." | Tee-Object -FilePath $log -Append
        "You may have a newer CMSIS-DSP version; arm_cfft_f32 expects legacy helper." | Tee-Object -FilePath $log -Append
        "➡️ Suggestion: copy 'arm_bitreversal2.c' from CMSIS-DSP 1.10.0 and include it." | Tee-Object -FilePath $log -Append
    } else {
        "OK: arm_bitreversal_32 present." | Tee-Object -FilePath $log -Append
    }
} else {
    "ERROR: arm_bitreversal.c missing!" | Tee-Object -FilePath $log -Append
}

# 3️⃣  Check for missing transform files
$needed = @(
    "arm_cfft_f32.c",
    "arm_cfft_radix8_f32.c",
    "arm_rfft_fast_init_f32.c",
    "arm_rfft_fast_f32.c"
)
foreach ($file in $needed) {
    $found = Get-ChildItem -Path $drivers -Recurse -Filter $file | Select-Object -First 1
    if (-not $found) {
        "⚠️ Missing: $file" | Tee-Object -FilePath $log -Append
    }
}

# 4️⃣  Clean leftover build cache
$debugDir = Join-Path $root "Debug"
if (Test-Path $debugDir) {
    Remove-Item -Path (Join-Path $debugDir "*") -Recurse -Force -ErrorAction SilentlyContinue
    "Cleaned Debug folder cache." | Tee-Object -FilePath $log -Append
}

"✅ CMSIS-DSP sanity check complete. See dsp_fix_log.txt for details." | Tee-Object -FilePath $log -Append
