# === DSP Cleanup Script for STM32F4 (Cortex-M4) ===
# Moves unsupported NEON / F16 / MVE files out of build path.

$DSP_DIR = "Drivers/CMSIS/DSP/Source"
$DISABLED_DIR = "$DSP_DIR/_disabled_dsp"

Write-Host "Creating backup folder: $DISABLED_DIR"
New-Item -ItemType Directory -Force -Path $DISABLED_DIR | Out-Null

Write-Host "Searching for unsupported NEON/F16/MVE files..."
Get-ChildItem -Path $DSP_DIR -Recurse -Include *neon*,*NEON*,*f16*,*F16*,*mve*,*MVE* | ForEach-Object {
    Move-Item -Path $_.FullName -Destination $DISABLED_DIR -Force
    Write-Host "Moved: $($_.Name)"
}

Write-Host "`n✅ Cleanup complete. All unsupported files moved to:"
Write-Host "→ $DISABLED_DIR"
