
#ifndef FFT_UTILS_H
#define FFT_UTILS_H

#include "arm_math.h"   // CMSIS DSP
#include <stdint.h>

/* -------------------------------------------------------------------
 *  FFT configuration parameters
 * ------------------------------------------------------------------- */
#define FFT_LEN           64
#define MAX_KEEP_BINS     8
#define ENERGY_THRESHOLD  0.90f

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Perform FFT-based pruning / compression of PCA scores.
 *
 * @param scores: Input float array (time-domain signal or PCA scores)
 * @param len: Length of the input (≤ FFT_LEN)
 * @param qre_out: Quantized real bins output (int16_t)
 * @param qim_out: Quantized imaginary bins output (int16_t)
 * @param kept_bins: Array of indices of kept bins
 * @param n_kept: Number of bins actually kept
 * @param total_bins: Total bins considered
 * @param energy_kept: Fraction of total energy preserved (0–1)
 *
 * @return int 0 = OK, negative on error
 */
int fft_prune(const float *scores, int len,
              int16_t *qre_out, int16_t *qim_out,
              int *kept_bins, int *n_kept,
              int *total_bins, float *energy_kept);

/**
 * @brief Run full FFT compression + quantization + inverse reconstruction.
 */
void run_fft_compress(float *input, int len);

#ifdef __cplusplus
}
#endif

#endif /* FFT_UTILS_H */


//#ifndef FFT_UTILS_H__
//#define FFT_UTILS_H__
//
//#include <stdint.h>
//
///*
// * fft_prune
// *
// * Inputs:
// *   scores[len]         - real-valued principal component scores (len = sample_count)
// *   len                 - number of valid samples (<= BATCH_M)
// *
// * Outputs:
// *   kept_bins[out_n]    - indices of kept frequency bins (0..FFT_LEN-1)
// *   out_n               - pointer to int, number of kept bins returned
// *   out_qre[out_n]      - quantized real parts (int16) for each kept bin
// *   out_qim[out_n]      - quantized imag parts (int16) for each kept bin
// *   out_qbytes          - pointer to int, number of bytes required to store quantized bins (filled)
// *   out_recon_mse       - pointer to float, MSE between reconstructed PC (first len samples) and original scores
// *
// * Returns 0 on success, <0 on failure.
// *
// * Notes:
// *  - Implementation currently uses an O(N^2) direct DFT for portability.
// *  - FFT_LEN is fixed to 64 (power-of-two >= typical BATCH_M=60). You may change FFT_LEN if needed.
// */
//int fft_prune(const float *scores, int len,
//              int16_t *out_qre, int16_t *out_qim, int *kept_bins, int *out_n,
//              int *out_qbytes, float *out_recon_mse);
//
//#endif /* FFT_UTILS_H__ */


#include "fft_utils.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "main.h"   // contains N_VARS definition

/* Tunable parameters */
#ifndef FFT_LEN
#define FFT_LEN 64           /* next power-of-two >= BATCH_M (60) */
#endif
#ifndef ENERGY_THRESHOLD
#define ENERGY_THRESHOLD 0.90f
#endif
#ifndef MAX_KEEP_BINS
#define MAX_KEEP_BINS 8
#endif
#define N_VARS 6

/* Internal complex number helpers (float) */
typedef struct { float re, im; } cplx;

/* Simple DFT (forward): input real[] length N -> output complex[] length N */
static void dft_forward_real(const float *real_in, int N, cplx *out)
{
    for (int k = 0; k < N; ++k) {
        float acc_re = 0.0f;
        float acc_im = 0.0f;
        for (int n = 0; n < N; ++n) {
            float angle = -2.0f * (float)M_PI * (float)k * (float)n / (float)N;
            float cr = cosf(angle);
            float ci = sinf(angle);
            acc_re += real_in[n] * cr;
            acc_im += real_in[n] * ci;
        }
        out[k].re = acc_re;
        out[k].im = acc_im;
    }
}

/* Inverse DFT from complex spectrum (length N) -> real_out (length N) */
static void dft_inverse_real(const cplx *spec, int N, float *real_out)
{
    for (int n = 0; n < N; ++n) {
        float acc = 0.0f;
        for (int k = 0; k < N; ++k) {
            float angle = 2.0f * (float)M_PI * (float)k * (float)n / (float)N;
            acc += spec[k].re * cosf(angle) - spec[k].im * sinf(angle);
        }
        real_out[n] = acc / (float)N;
    }
}

/* Helper: absolute-squared (energy) of complex number */
static inline float cplx_energy(const cplx *c) { return c->re * c->re + c->im * c->im; }

/* Simple selection of top bins by energy (returns indices in descending order) */
static void select_top_bins(const float *energies, int N, int max_bins, int *out_idx, int *out_count, float energy_threshold)
{
    /* copy energies into a local array of (value, index) pairs */
    typedef struct { float e; int idx; } pair;
    pair *arr = (pair *)malloc(sizeof(pair) * N);
    for (int i = 0; i < N; ++i) { arr[i].e = energies[i]; arr[i].idx = i; }

    /* sort descending by energy (simple selection sort since N small) */
    for (int i = 0; i < N - 1; ++i) {
        int m = i;
        for (int j = i + 1; j < N; ++j) if (arr[j].e > arr[m].e) m = j;
        if (m != i) { pair tmp = arr[i]; arr[i] = arr[m]; arr[m] = tmp; }
    }

    /* choose bins until energy threshold met or max_bins reached */
    float total = 0.0f;
    for (int i = 0; i < N; ++i) total += arr[i].e;
    float cum = 0.0f;
    int chosen = 0;
    for (int i = 0; i < N && chosen < max_bins; ++i) {
        cum += arr[i].e;
        out_idx[chosen++] = arr[i].idx;
        if (total > 0.0f && (cum / total) >= energy_threshold) break;
    }
    *out_count = chosen;
    free(arr);
}

/* Quantize kept bins (real+imag) to int16 using symmetric scaling */
static int quantize_bins(const cplx *spec, const int *bins, int nbins, int16_t *out_qre, int16_t *out_qim, float *scale_out)
{
    float max_abs = 0.0f;
    for (int i = 0; i < nbins; ++i) {
        int idx = bins[i];
        float a = fabsf(spec[idx].re);
        float b = fabsf(spec[idx].im);
        if (a > max_abs) max_abs = a;
        if (b > max_abs) max_abs = b;
    }
    if (max_abs < 1e-9f) max_abs = 1.0f; /* avoid div by zero */

    /* scale so that max_abs maps to int16 max */
    float scale = max_abs / 32767.0f;
    for (int i = 0; i < nbins; ++i) {
        int idx = bins[i];
        int32_t qre = (int32_t)roundf(spec[idx].re / scale);
        int32_t qim = (int32_t)roundf(spec[idx].im / scale);
        if (qre > 32767) qre = 32767; if (qre < -32768) qre = -32768;
        if (qim > 32767) qim = 32767; if (qim < -32768) qim = -32768;
        out_qre[i] = (int16_t)qre;
        out_qim[i] = (int16_t)qim;
    }
    if (scale_out) *scale_out = scale;
    return 0;
}

/* Unquantize bins into complex spectrum copy (spec_out) using scale */
static void unquantize_bins_into_spec(cplx *spec_out, const int *bins, int nbins, const int16_t *qre, const int16_t *qim, float scale)
{
    /* ensure spec_out is zeroed by caller */
    for (int i = 0; i < nbins; ++i) {
        int idx = bins[i];
        spec_out[idx].re = ((float)qre[i]) * scale;
        spec_out[idx].im = ((float)qim[i]) * scale;
    }
}

/* Public function */
int fft_prune(const float *scores, int len,
              int16_t *out_qre, int16_t *out_qim, int *kept_bins, int *out_n,
              int *out_qbytes, float *out_recon_mse)
{
    if (!scores || !kept_bins || !out_n || !out_qbytes || !out_recon_mse) return -1;
    if (len <= 0 || len > FFT_LEN) return -2;

    /* build real input of length FFT_LEN (zero padded) */
    float real_in[FFT_LEN];
    for (int i = 0; i < FFT_LEN; ++i) real_in[i] = 0.0f;
    for (int i = 0; i < len; ++i) real_in[i] = scores[i];

    /* forward DFT -> spec[0..FFT_LEN-1] */
    cplx spec[FFT_LEN];
    dft_forward_real(real_in, FFT_LEN, spec);

    /* compute energies */
    float energies[FFT_LEN];
    float total_energy = 0.0f;
    for (int k = 0; k < FFT_LEN; ++k) {
        energies[k] = cplx_energy(&spec[k]);
        total_energy += energies[k];
    }

    /* select top bins */
    int sel_idx[FFT_LEN];
    int sel_count = 0;
    select_top_bins(energies, FFT_LEN, MAX_KEEP_BINS, sel_idx, &sel_count, ENERGY_THRESHOLD);

    /* ensure conjugate pairs included for real signal (keep k and N-k) */
    /* Build a small unique set including conjugates */
    int uniq[FFT_LEN];
    int uniq_count = 0;
    for (int i = 0; i < sel_count; ++i) {
        int k = sel_idx[i];
        /* include k */
        int found = 0;
        for (int t = 0; t < uniq_count; ++t) if (uniq[t] == k) { found = 1; break; }
        if (!found) uniq[uniq_count++] = k;
        /* include conjugate N-k (if not equal and not already present) */
        int kc = (k == 0) ? 0 : (FFT_LEN - k);
        if (kc != k) {
            found = 0;
            for (int t = 0; t < uniq_count; ++t) if (uniq[t] == kc) { found = 1; break; }
            if (!found) uniq[uniq_count++] = kc;
        }
    }

    /* limit uniq_count to MAX_KEEP_BINS (if exceeded, truncate) */
    if (uniq_count > MAX_KEEP_BINS) uniq_count = MAX_KEEP_BINS;

    /* sort uniq ascending (for consistent printing) */
    for (int i = 0; i < uniq_count - 1; ++i) {
        int m = i;
        for (int j = i + 1; j < uniq_count; ++j) if (uniq[j] < uniq[m]) m = j;
        if (m != i) { int t = uniq[i]; uniq[i] = uniq[m]; uniq[m] = t; }
    }

    /* quantize selected bins */
    float scale = 1.0f;
    quantize_bins(spec, uniq, uniq_count, out_qre, out_qim, &scale);

    /* compute quantized bytes: for each kept bin we store index (1 byte) + qre(2 bytes) + qim(2 bytes)
       index size assumed 1 byte (enough for FFT_LEN=64). Adjust if larger. */
    int bytes_for_bins = uniq_count * (1 + 2 + 2); /* idx + re + im */
    int bytes_means = (N_VARS * 4); /* means as float32 */
    int bytes_eigvec = (N_VARS * 4);
    int total_bytes = bytes_means + bytes_eigvec + bytes_for_bins;

    /* reconstruct spectrum from quantized bins */
    cplx spec_pruned[FFT_LEN];
    for (int i = 0; i < FFT_LEN; ++i) { spec_pruned[i].re = 0.0f; spec_pruned[i].im = 0.0f; }
    unquantize_bins_into_spec(spec_pruned, uniq, uniq_count, out_qre, out_qim, scale);

    /* inverse DFT to obtain reconstructed time-domain of length FFT_LEN */
    float recon_full[FFT_LEN];
    dft_inverse_real(spec_pruned, FFT_LEN, recon_full);

    /* compute MSE between first 'len' samples of recon_full and original scores */
    double sse = 0.0;
    for (int i = 0; i < len; ++i) {
        double d = (double)scores[i] - (double)recon_full[i];
        sse += d * d;
    }
    double denom = (double)len;
    float recon_mse = (denom > 0.0) ? (float)(sse / denom) : 0.0f;

    /* copy uniq into kept_bins out (as int) and set out_n */
    for (int i = 0; i < uniq_count; ++i) kept_bins[i] = uniq[i];
    *out_n = uniq_count;
    *out_qbytes = total_bytes;
    *out_recon_mse = recon_mse;

    return 0;
}
