/*
 * esp_comm.c  (PRODUCTION-READY, PERSISTENT TCP)
 *
 * Robust ESP-01 AT wrapper for STM32 HAL (UART5).
 * - Response reader with idle detection
 * - Works around "busy p..." behavior
 * - Prompt-delay fix (must wait before sending payload)
 * - Soft recover on CIPSEND/CIPSTART failures
 * - Persistent TCP mode: open once, reuse for many sends
 * - Detailed debug prints
 *
 * Notes:
 *  - Expects extern UART_HandleTypeDef huart5; extern UART_HandleTypeDef huart3; (debug on huart3)
 *  - Uses blocking HAL UART calls (as per your setup)
 */

#include "main.h"
#include "usart.h"
#include "gpio.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

/* ===== CONFIG ===== */
#define ESP_DEFAULT_TIMEOUT     8000U   /* General operations (ms) */
#define ESP_PROMPT_TIMEOUT      5000U   /* Waiting for '>' prompt (ms) */
#define ESP_SEND_TIMEOUT        12000U  /* Sending payload (ms) */
#define ESP_IDLE_GAP            200U    /* Idle gap for esp_read_resp (ms) */

/* Mandatory 50ms delay after '>' before sending payload (some modules need this) */
#define ESP_PROMPT_DELAY_MS     60U

/* UART used for ESP */
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart3;

/* ESP UART handle macro - keep compatibility with earlier code */
#define ESP_UART_HANDLE huart5

/* dbg_print provided by main.c */
extern void dbg_print(const char *fmt, ...);

/* ============================================================
 * Module state for persistent TCP
 * ============================================================*/
static bool esp_tcp_persistent_connected = false;
static char esp_tcp_ip[32] = {0};
static int  esp_tcp_port = 0;

/* ============================================================
 *     RESPONSE READER (with idle detection & chunked append)
 * ============================================================*/
static int esp_read_resp(char *buf, int maxlen, uint32_t timeout_ms, uint32_t idle_ms)
{
    if (!buf || maxlen < 2) return 0;

    uint32_t start = HAL_GetTick();
    uint32_t last  = start;
    int idx = 0;

    while ((HAL_GetTick() - start) < timeout_ms)
    {
        uint8_t ch;
        HAL_StatusTypeDef r = HAL_UART_Receive(&ESP_UART_HANDLE, &ch, 1, 30);

        if (r == HAL_OK)
        {
            if (idx < (maxlen - 1)) buf[idx++] = ch;
            last = HAL_GetTick();
        }
        else
        {
            if ((HAL_GetTick() - last) >= idle_ms)
                break;
        }
    }

    if (idx >= maxlen) idx = maxlen - 1;
    buf[idx] = 0;
    return idx;
}

/* ============================================================
 *    RAW SEND (no trailing read)
 * ============================================================*/
static bool esp_send_raw(const char *cmd, uint32_t timeout_ms)
{
    if (!cmd) return false;

    HAL_StatusTypeDef tx = HAL_UART_Transmit(&ESP_UART_HANDLE,
                                             (uint8_t*)cmd,
                                             strlen(cmd),
                                             timeout_ms);
    if (tx != HAL_OK)
    {
        dbg_print("[ESP] TX error %d\r\n", tx);
        return false;
    }
    return true;
}

/* ============================================================
 *  SEND + PRINT RESPONSE (best-effort)
 * ============================================================*/
bool esp_send_at_and_print(const char *cmd, uint32_t timeout_ms)
{
    char resp[512];

    dbg_print("[ESP SEND] %s", cmd);

    if (!esp_send_raw(cmd, 2000))
    {
        dbg_print("[ESP] TX fail\r\n");
        return false;
    }

    int got = esp_read_resp(resp, sizeof(resp), timeout_ms, ESP_IDLE_GAP);

    if (got > 0)
    {
        dbg_print("[ESP RAW] %s\r\n", resp);
        return true;
    }

    dbg_print("[ESP RAW] <timeout>\r\n");
    return false;
}

/* ============================================================
 *  CMD + EXPECT (returns true if 'expect' found in response)
 * ============================================================*/
static bool esp_send_cmd_expect_print(const char *cmd, const char *expect, uint32_t timeout_ms)
{
    char resp[512];

    if (cmd)
    {
        dbg_print("[ESP SEND] %s", cmd);

        if (!esp_send_raw(cmd, 2000))
        {
            dbg_print("[ESP] TX fail\r\n");
            return false;
        }
    }

    int got = esp_read_resp(resp, sizeof(resp), timeout_ms, ESP_IDLE_GAP);

    if (got > 0)
    {
        dbg_print("[ESP RAW] %s\r\n", resp);
        if (!expect) return true;
        return strstr(resp, expect) != NULL;
    }

    dbg_print("[ESP RAW] <timeout>\r\n");
    return false;
}

/* ============================================================
 *   SOFT RECOVERY (abort CIPSEND, re-sync)
 * ============================================================*/
static void esp_soft_recover(void)
{
    dbg_print("[ESP] soft recover: send ESC, short AT, small delay\r\n");

    uint8_t esc = 0x1B;
    HAL_UART_Transmit(&ESP_UART_HANDLE, &esc, 1, 100);
    HAL_Delay(30);
    HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)"AT\r\n", 4, 200);
    HAL_Delay(120);
}

/* ============================================================
 *   MODULE CHECK (public)
 * ============================================================*/
bool esp_check_module(uint32_t timeout_ms)
{
    dbg_print("[ESP CHECK] AT\r\n");
    esp_send_at_and_print("AT\r\n", timeout_ms);

    dbg_print("[ESP CHECK] AT+GMR\r\n");
    esp_send_at_and_print("AT+GMR\r\n", timeout_ms);

    return true;
}

/* ============================================================
 *   WIFI INIT (robust)
 * ============================================================*/
bool esp_init_wifi_verbose(const char *ssid, const char *password, uint32_t timeout_ms)
{
    char cmd[256];
    char resp[512];

    dbg_print("[ESP WIFI] init: disabling echo, resetting, set mode, then CWJAP\r\n");

    /* disable echo (best effort) */
    esp_send_cmd_expect_print("ATE0\r\n", "OK", 2000);

    /* reset and read boot text (best-effort) */
    esp_send_raw("AT+RST\r\n", 2000);
    (void) esp_read_resp(resp, sizeof(resp), 4000, 250);

    /* set station mode */
    esp_send_cmd_expect_print("AT+CWMODE=1\r\n", "OK", 2000);

    HAL_Delay(200);

    snprintf(cmd, sizeof(cmd), "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, password);

    const int max_connect_attempts = 6;
    uint32_t attempt_delay = 800U; /* ms */

    for (int attempt = 1; attempt <= max_connect_attempts; ++attempt) {
        dbg_print("[ESP WIFI] CWJAP attempt %d/%d\r\n", attempt, max_connect_attempts);

        /* send join command */
        if (!esp_send_raw(cmd, 2000)) {
            dbg_print("[ESP WIFI] TX failed for CWJAP\r\n");
            HAL_Delay(attempt_delay);
            attempt_delay *= 2;
            continue;
        }

        /* Wait longer (timeout_ms), but be tolerant of 'busy p' */
        int got = esp_read_resp(resp, sizeof(resp), timeout_ms + (attempt * 1000U), 400);

        if (got > 0) {
            dbg_print("[ESP RAW] %s\r\n", resp);

            /* If module says busy, wait a bit and try to read leftover */
            if (strstr(resp, "busy") || strstr(resp, "busy p")) {
                dbg_print("[ESP WIFI] module busy, waiting 1500ms then re-read\r\n");
                HAL_Delay(1500);
                (void) esp_read_resp(resp, sizeof(resp), 2000, 300);
                dbg_print("[ESP RAW after wait] %s\r\n", resp);
            }

            /* Look for wifi join indicators */
            if (strstr(resp, "WIFI CONNECTED") || strstr(resp, "WIFI GOT IP") || strstr(resp, "WIFI ")) {
                dbg_print("[ESP WIFI] join response contained WIFI -> success\r\n");
                return true;
            }

            /* if we got 'OK' but no WIFI lines, keep waiting small extra time */
            if (strstr(resp, "OK") && (strstr(resp, "WIFI") == NULL)) {
                dbg_print("[ESP WIFI] got OK but no WIFI line, extra wait 2000ms\r\n");
                (void) esp_read_resp(resp, sizeof(resp), 2000, 300);
                if (strstr(resp, "WIFI CONNECTED") || strstr(resp, "WIFI GOT IP") || strstr(resp, "WIFI "))
                    return true;
            }
        } else {
            dbg_print("[ESP WIFI] no response to CWJAP (attempt %d)\r\n", attempt);
        }

        /* If response contained 'FAIL' or 'ERROR' try again after delay */
        if (strstr(resp, "FAIL") || strstr(resp, "ERROR")) {
            dbg_print("[ESP WIFI] response contained FAIL/ERROR, backing off %ums\r\n", attempt_delay);
            HAL_Delay(attempt_delay);
            attempt_delay *= 2;
            continue;
        }

        /* generic backoff before next try */
        HAL_Delay(attempt_delay);
        attempt_delay *= 2;
    }

    dbg_print("[ESP WIFI] all join attempts failed\r\n");
    return false;
}

/* ============================================================
 *   TCP CONNECT (one-shot helper; kept for compatibility)
 * ============================================================*/
bool esp_tcp_connect_verbose(const char *ip, int port, uint32_t timeout_ms)
{
    char cmd[128];
    snprintf(cmd, sizeof(cmd),
             "AT+CIPSTART=\"TCP\",\"%s\",%d\r\n",
             ip, port);

    dbg_print("[ESP TCP] %s", cmd);

    if (esp_send_cmd_expect_print(cmd, "CONNECT", timeout_ms))
    {
        dbg_print("[ESP TCP] CONNECT OK\r\n");
        return true;
    }

    if (esp_send_cmd_expect_print(NULL, "OK", timeout_ms))
    {
        dbg_print("[ESP TCP] CIPSTART OK\r\n");
        return true;
    }

    dbg_print("[ESP TCP] CIPSTART FAILED\r\n");
    return false;
}

/* ============================================================
 *   TCP SEND (one-shot helper; kept for compatibility)
 * ============================================================*/
bool esp_tcp_send_verbose(const uint8_t *data, uint16_t len, uint32_t timeout_ms)
{
    if (!data || len == 0) return false;

    char cmd[64];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%u\r\n", len);

    dbg_print("[ESP TCP] CIPSEND %u bytes\r\n", len);

    if (!esp_send_raw(cmd, 2000))
    {
        dbg_print("[ESP TCP] failed to TX CIPSEND\r\n");
        return false;
    }

    /* Wait for '>' */
    char resp[256];
    int got = esp_read_resp(resp, sizeof(resp),
                            ESP_PROMPT_TIMEOUT,
                            200);

    dbg_print("[ESP RAW] %s\r\n", resp);

    if (got <= 0)
    {
        dbg_print("[ESP TCP] No prompt after CIPSEND\r\n");
        esp_soft_recover();
        return false;
    }

    if (!strstr(resp, ">"))
    {
        if (strstr(resp, "link is not valid"))
        {
            dbg_print("[ESP TCP] link invalid → resetting\r\n");
            esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", 2000);
            HAL_Delay(100);
        }

        esp_soft_recover();
        return false;
    }

    /* MUST WAIT — STABILITY PATCH */
    dbg_print("[ESP TCP] Prompt received → delaying %d ms\r\n", ESP_PROMPT_DELAY_MS);
    HAL_Delay(ESP_PROMPT_DELAY_MS);

    /* Send actual payload */
    dbg_print("[ESP TCP] Sending RAW payload (%u bytes)\r\n", len);

    HAL_StatusTypeDef tx =
        HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)data, len, ESP_SEND_TIMEOUT);

    if (tx != HAL_OK)
    {
        dbg_print("[ESP TCP] TX fail (%d)\r\n", tx);
        esp_soft_recover();
        return false;
    }

    /* Wait for SEND OK */
    got = esp_read_resp(resp, sizeof(resp),
                        ESP_SEND_TIMEOUT,
                        250);

    if (got > 0)
    {
        dbg_print("[ESP RAW] %s\r\n", resp);

        if (strstr(resp, "SEND OK"))
        {
            dbg_print("[ESP TCP] SEND OK\r\n");
            return true;
        }
    }

    dbg_print("[ESP TCP] SEND FAIL\r\n");
    esp_soft_recover();
    return false;
}

/* ============================================================
 *   TCP CLOSE
 * ============================================================*/
void esp_tcp_close_verbose(uint32_t timeout_ms)
{
    esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", timeout_ms);
}

/* ============================================================
 *   PERSISTENT TCP API (NEW)
 *   - open once (esp_tcp_open_persistent)
 *   - send many (esp_tcp_send_persistent)
 *   - close (esp_tcp_close_persistent)
 * ============================================================*/

/* Internal helper: try to open TCP and set persistent state */
bool esp_tcp_open_persistent(const char *ip, int port, uint32_t timeout_ms)
{
    if (!ip) return false;

    /* if already open with same endpoint, return success */
    if (esp_tcp_persistent_connected &&
        strcmp(esp_tcp_ip, ip) == 0 && esp_tcp_port == port)
    {
        dbg_print("[ESP TCP PERSIST] already connected to %s:%d\r\n", ip, port);
        return true;
    }

    /* close any previous connection first */
    if (esp_tcp_persistent_connected) {
        dbg_print("[ESP TCP PERSIST] closing stale persistent connection\r\n");
        esp_tcp_close_verbose(2000);
        esp_tcp_persistent_connected = false;
    }

    char cmd[128];
    snprintf(cmd, sizeof(cmd),
             "AT+CIPSTART=\"TCP\",\"%s\",%d\r\n",
             ip, port);

    dbg_print("[ESP TCP PERSIST] Opening %s:%d\r\n", ip, port);

    /* send and wait for CONNECT or OK */
    if (esp_send_cmd_expect_print(cmd, "CONNECT", timeout_ms) ||
        esp_send_cmd_expect_print(NULL, "OK", timeout_ms))
    {
        dbg_print("[ESP TCP PERSIST] CIPSTART OK -> persistent connected\r\n");
        /* store endpoint */
        strncpy(esp_tcp_ip, ip, sizeof(esp_tcp_ip)-1);
        esp_tcp_port = port;
        esp_tcp_persistent_connected = true;
        return true;
    }

    dbg_print("[ESP TCP PERSIST] CIPSTART FAILED\r\n");
    esp_tcp_persistent_connected = false;
    return false;
}

/* Persistent send: assumes an open persistent connection. Will attempt to auto-reopen once. */
bool esp_tcp_send_persistent(const uint8_t *data, uint16_t len, uint32_t timeout_ms)
{
    if (!data || len == 0) return false;

    if (!esp_tcp_persistent_connected) {
        dbg_print("[ESP TCP PERSIST] not connected → attempting open to %s:%d\r\n", esp_tcp_ip[0]?esp_tcp_ip:"<unknown>", esp_tcp_port);
        if (!esp_tcp_open_persistent(esp_tcp_ip, esp_tcp_port, timeout_ms)) {
            dbg_print("[ESP TCP PERSIST] open failed, cannot send\r\n");
            return false;
        }
    }

    /* CIPSEND as usual */
    char cmd[64];
    snprintf(cmd, sizeof(cmd), "AT+CIPSEND=%u\r\n", len);

    dbg_print("[ESP TCP PERSIST] CIPSEND %u\r\n", len);
    if (!esp_send_raw(cmd, 2000)) {
        dbg_print("[ESP TCP PERSIST] TX fail for CIPSEND cmd\r\n");
        esp_tcp_persistent_connected = false;
        return false;
    }

    /* wait for > prompt */
    char resp[512];
    int got = esp_read_resp(resp, sizeof(resp), ESP_PROMPT_TIMEOUT, 200);

    dbg_print("[ESP RAW] %s\r\n", resp);

    if (got <= 0 || !strstr(resp, ">")) {
        dbg_print("[ESP TCP PERSIST] No prompt or unexpected response\r\n");
        /* try to see if link invalid or connection closed; close & mark not connected */
        if (strstr(resp, "link is not valid") || strstr(resp, "ERROR") || strstr(resp, "CLOSED")) {
            dbg_print("[ESP TCP PERSIST] link invalid/closed -> cleaning up\r\n");
            esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", 2000);
        }
        esp_tcp_persistent_connected = false;
        return false;
    }

    /* small prompt delay */
    HAL_Delay(ESP_PROMPT_DELAY_MS);

    HAL_StatusTypeDef tx = HAL_UART_Transmit(&ESP_UART_HANDLE, (uint8_t*)data, len, ESP_SEND_TIMEOUT);
    if (tx != HAL_OK) {
        dbg_print("[ESP TCP PERSIST] payload TX error %d\r\n", tx);
        esp_tcp_persistent_connected = false;
        esp_soft_recover();
        return false;
    }

    /* wait for SEND OK */
    got = esp_read_resp(resp, sizeof(resp), timeout_ms, 250);
    dbg_print("[ESP RAW] %s\r\n", resp);

    if (got > 0 && strstr(resp, "SEND OK")) {
        dbg_print("[ESP TCP PERSIST] SEND OK\r\n");
        return true;
    }

    dbg_print("[ESP TCP PERSIST] SEND FAIL -> will reset persistent flag\r\n");
    esp_tcp_persistent_connected = false;
    esp_soft_recover();
    return false;
}

/* Close persistent connection (public) */
void esp_tcp_close_persistent(uint32_t timeout_ms)
{
    dbg_print("[ESP TCP PERSIST] Closing persistent connection\r\n");
    esp_send_cmd_expect_print("AT+CIPCLOSE\r\n", "CLOSED", timeout_ms);
    esp_tcp_persistent_connected = false;
    esp_tcp_ip[0] = 0;
    esp_tcp_port = 0;
}

