/* Core/Src/pca_prune.c
   Your PCA code with added serialization accessor.
   NOTE: keep N_VARS, BATCH_M macros consistent with your project.
*/

#include "pca_prune.h"
#include "fft_utils.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "usart.h"
extern UART_HandleTypeDef huart3;

#include <stdarg.h>

/* internal storage */
static float data_buf[BATCH_M][N_VARS];
static int sample_count = 0;

/* static serialization buffer (returned via accessor) */
#define SER_BUF_MAX 512
static uint8_t ser_buf[SER_BUF_MAX];
static uint16_t ser_len = 0;

/* helpers */
static void zero_buf(void) {
    memset(data_buf, 0, sizeof(data_buf));
    sample_count = 0;
    ser_len = 0;
}

/* init */
void pca_prune_init(void) {
    zero_buf();
    dbg_print("[PCA] pca_prune_init: BATCH_M=%d N_VARS=%d\r\n", BATCH_M, N_VARS);
}

/* feed sample (unchanged) */
void pca_prune_feed_sample(const float sample[N_VARS]) {
    if (sample == NULL) return;
    if (sample_count < BATCH_M) {
        for (int j = 0; j < N_VARS; ++j) data_buf[sample_count][j] = sample[j];
        sample_count++;
        dbg_print("[PCA] fed sample #%d: [", sample_count);
        for (int j = 0; j < N_VARS; ++j) dbg_print("%.3f%s", sample[j], (j+1==N_VARS) ? "" : ", ");
        dbg_print("]\r\n");
    } else {
        memmove(&data_buf[0], &data_buf[1], sizeof(float) * N_VARS * (BATCH_M - 1));
        for (int j = 0; j < N_VARS; ++j) data_buf[BATCH_M - 1][j] = sample[j];
        dbg_print("[PCA] buffer full -> rolling, still count=%d\r\n", sample_count);
    }
}

/* compute means */
static void compute_means(float means[N_VARS]) {
    for (int j = 0; j < N_VARS; ++j) means[j] = 0.0f;
    if (sample_count <= 0) return;
    for (int i = 0; i < sample_count; ++i)
        for (int j = 0; j < N_VARS; ++j)
            means[j] += data_buf[i][j];
    float inv = 1.0f / (float)sample_count;
    for (int j = 0; j < N_VARS; ++j) means[j] *= inv;
}

/* covariance, power iteration, project, reconstruct (unchanged) */
/* ... (reinclude the same compute_covariance, power_iteration_top1,
   project_scores, reconstruct_from_scores, compute_mse_internal,
   compute_total_variance functions from your prior file) ... */

/* For brevity here, paste the unchanged functions from your file:
   compute_covariance, power_iteration_top1, project_scores,
   reconstruct_from_scores, compute_mse_internal, compute_total_variance
   exactly as previously provided by you.
*/

/* --- begin unchanged functions (copy verbatim from your earlier file) --- */

/* compute unbiased covariance matrix (N_VARS x N_VARS) */
static void compute_covariance(const float means[N_VARS], float cov[N_VARS][N_VARS]) {
    for (int i = 0; i < N_VARS; ++i)
        for (int j = 0; j < N_VARS; ++j)
            cov[i][j] = 0.0f;
    if (sample_count < 2) return;
    for (int t = 0; t < sample_count; ++t) {
        for (int i = 0; i < N_VARS; ++i) {
            float a = data_buf[t][i] - means[i];
            for (int j = 0; j < N_VARS; ++j) {
                float b = data_buf[t][j] - means[j];
                cov[i][j] += a * b;
            }
        }
    }
    float denom = 1.0f / (float)(sample_count - 1);
    for (int i = 0; i < N_VARS; ++i)
        for (int j = 0; j < N_VARS; ++j)
            cov[i][j] *= denom;
}

/* power iteration (top-1 eigenvector) */
static void power_iteration_top1(const float cov[N_VARS][N_VARS], float eig[N_VARS]) {
    for (int i = 0; i < N_VARS; ++i) eig[i] = 1.0f;
    {
        float s = 0.0f;
        for (int i = 0; i < N_VARS; ++i) s += eig[i]*eig[i];
        s = sqrtf(s); if (s <= 1e-12f) s = 1.0f;
        for (int i = 0; i < N_VARS; ++i) eig[i] /= s;
    }
    for (int it = 0; it < 100; ++it) {
        float y[N_VARS];
        for (int i = 0; i < N_VARS; ++i) { y[i] = 0.0f; for (int j = 0; j < N_VARS; ++j) y[i] += cov[i][j] * eig[j]; }
        float norm = 0.0f;
        for (int i = 0; i < N_VARS; ++i) norm += y[i]*y[i];
        if (norm <= 1e-20f) break;
        norm = sqrtf(norm);
        float diff = 0.0f;
        for (int i = 0; i < N_VARS; ++i) {
            float v = y[i]/norm;
            float d = v - eig[i];
            diff += d*d;
            eig[i] = v;
        }
        if (diff < 1e-12f) break;
    }
}

static void project_scores(const float means[N_VARS], const float eig[N_VARS], float scores[BATCH_M]) {
    for (int t = 0; t < sample_count; ++t) {
        float s = 0.0f;
        for (int j = 0; j < N_VARS; ++j) s += (data_buf[t][j] - means[j]) * eig[j];
        scores[t] = s;
    }
}

static void reconstruct_from_scores(const float means[N_VARS], const float eig[N_VARS], const float scores[BATCH_M], float recon[BATCH_M][N_VARS]) {
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j)
            recon[t][j] = means[j] + scores[t] * eig[j];
}

static float compute_mse_internal(const float recon[BATCH_M][N_VARS]) {
    double sse = 0.0;
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j) {
            double d = (double)data_buf[t][j] - (double)recon[t][j];
            sse += d * d;
        }
    double denom = (double)sample_count * (double)N_VARS;
    if (denom <= 0.0) return 0.0f;
    return (float)(sse / denom);
}

static float compute_total_variance(const float means[N_VARS]) {
    double s = 0.0;
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j) {
            double d = (double)data_buf[t][j] - (double)means[j];
            s += d*d;
        }
    double denom = (double)sample_count * (double)N_VARS;
    if (denom <= 0.0) return 0.0f;
    return (float)(s / denom);
}

/* --- end unchanged functions --- */

/* The main public function (mostly unchanged) */
int pca_prune_maybe_run_and_report(void) {
    static uint32_t last_run_ms = 0;
    uint32_t now_ms = HAL_GetTick();

    dbg_print("[PCA] maybe_run called: sample_count=%d last_run=%lu now=%lu elapsed=%lu\r\n",
              sample_count, (unsigned long)last_run_ms, (unsigned long)now_ms, (unsigned long)(now_ms - last_run_ms));

    if (sample_count < BATCH_M && (now_ms - last_run_ms) < 60000UL) {
        dbg_print("[PCA] Not running: sample_count=%d elapsed=%lums (need %d or 60000ms)\r\n",
                  sample_count, (unsigned long)(now_ms - last_run_ms), BATCH_M);
        return 0;
    }
    if (sample_count < 4) {
        dbg_print("[PCA] Not enough samples to run PCA (have %d)\r\n", sample_count);
        return 0;
    }

    dbg_print("[PCA] Running PCA with %d samples (forced by timer/full)\r\n", sample_count);

    /* 1) Means */
    float means[N_VARS];
    compute_means(means);

    /* 2) Covariance */
    float cov[N_VARS][N_VARS];
    compute_covariance(means, cov);

    /* 3) Top-1 eigvec */
    float eigvec[N_VARS];
    power_iteration_top1(cov, eigvec);

    /* 4) Project -> scores */
    float scores[BATCH_M];
    project_scores(means, eigvec, scores);

    /* 5) Reconstruct & MSE */
    float recon[BATCH_M][N_VARS];
    reconstruct_from_scores(means, eigvec, scores, recon);
    float mse = compute_mse_internal(recon);

    /* 6) total variance and savings estimate */
    float tot_var = compute_total_variance(means);
    float savings_pct = 0.0f;
    if (tot_var > 1e-12f) savings_pct = (1.0f - (mse / tot_var)) * 100.0f;
    if (savings_pct < 0.0f) savings_pct = 0.0f;

    /* diagnostics (kept from your file) */
    dbg_print("\r\n=== PCA PRUNE REPORT ===\r\n");
    dbg_print("Samples: %d  N_VARS: %d  BATCH_M: %d\r\n", sample_count, N_VARS, BATCH_M);
    dbg_print("eigvec: ");
    for (int j = 0; j < N_VARS; ++j) dbg_print("%.4f ", eigvec[j]);
    dbg_print("\r\n");
    dbg_print("means:  ");
    for (int j = 0; j < N_VARS; ++j) dbg_print("%.3f ", means[j]);
    dbg_print("\r\n");
    dbg_print("MSE=%.6f  TotVar=%.6f  EstimatedSavings=%.2f%%\r\n",
              mse, tot_var, savings_pct);

    /* FFT prune of the top-1 scores (compressive sensing) */
    {
        int16_t qre[MAX_KEEP_BINS];
        int16_t qim[MAX_KEEP_BINS];
        int kept_idx[MAX_KEEP_BINS];
        int kept_n = 0;
        int qbytes = 0;
        float recon_mse = 0.0f;

        int rc = fft_prune(scores, sample_count,
                           qre, qim, kept_idx, &kept_n,
                           &qbytes, &recon_mse);
        if (rc == 0) {
            dbg_print("\r\n--- FFT PRUNE (scores) ---\r\n");
            dbg_print("Kept bins: %d  QuantBytes=%d  ReconMSE=%.6f\r\n", kept_n, qbytes, recon_mse);
            dbg_print("Indices: ");
            for (int i = 0; i < kept_n; ++i) dbg_print("%d ", kept_idx[i]);
            dbg_print("\r\nQuantized (re,im): ");
            for (int i = 0; i < kept_n; ++i) dbg_print("%d,%d ", (int)qre[i], (int)qim[i]);
            dbg_print("\r\n");

            int bytes_means = N_VARS * 4;
            int bytes_eigvec = N_VARS * 4;
            int total_bytes = bytes_means + bytes_eigvec + qbytes;
            float raw_bytes = (float)sample_count * N_VARS * sizeof(float);
            float real_saved = 100.0f * (1.0f - ((float)total_bytes / raw_bytes));
            dbg_print("Bytes: raw=%d compressed(est)=%d saved=%.2f%%\r\n", (int)raw_bytes, total_bytes, real_saved);

            /* === Build serialized payload into ser_buf ===
             * Format (little-endian):
             * [4] 'P' 'C' 'A' 'P'
             * [2] uint16_t sample_count
             * [1] uint8_t N_VARS
             * [4*N_VARS] means floats
             * [4*N_VARS] eigvec floats
             * [2] uint16_t kept_n
             * [2*kept_n] uint16_t kept_idx
             * [2*kept_n] int16_t qre
             * [2*kept_n] int16_t qim
             */
            uint8_t *p = ser_buf;
            int remaining = SER_BUF_MAX;
            /* magic */
            if (remaining < 4) { dbg_print("[PCA] ser buf too small\r\n"); }
            memcpy(p, "PCAP", 4); p += 4; remaining -= 4;
            /* sample_count */
            if (remaining < 2) { dbg_print("[PCA] ser buf too small\r\n"); }
            *(uint16_t*)p = (uint16_t)sample_count; p += 2; remaining -= 2;
            /* N_VARS */
            *p++ = (uint8_t)N_VARS; remaining -= 1;
            /* means */
            if (remaining < 4*N_VARS) { dbg_print("[PCA] ser buf too small\r\n"); }
            memcpy(p, means, 4*N_VARS); p += 4*N_VARS; remaining -= 4*N_VARS;
            /* eigvec */
            memcpy(p, eigvec, 4*N_VARS); p += 4*N_VARS; remaining -= 4*N_VARS;
            /* kept_n */
            *(uint16_t*)p = (uint16_t)kept_n; p += 2; remaining -= 2;
            /* kept_idx */
            for (int i = 0; i < kept_n; ++i) { *(uint16_t*)p = (uint16_t)kept_idx[i]; p += 2; remaining -= 2; }
            /* qre */
            for (int i = 0; i < kept_n; ++i) { *(int16_t*)p = qre[i]; p += 2; remaining -= 2; }
            /* qim */
            for (int i = 0; i < kept_n; ++i) { *(int16_t*)p = qim[i]; p += 2; remaining -= 2; }

            ser_len = (uint16_t)(p - ser_buf);
            dbg_print("[PCA] Serialized payload built: %d bytes\r\n", (int)ser_len);
        } else {
            dbg_print("[PCA] fft_prune failed rc=%d\r\n", rc);
            ser_len = 0;
        }
    }

    dbg_print("\r\n[PCA_SUMMARY] MSE=%.6f | TotVar=%.6f | Explained=%.2f%% | Samples=%d\r\n",
              mse, tot_var, (tot_var>1e-9f) ? (100.0f*(1.0f - mse / tot_var)) : 0.0f, sample_count);
    dbg_print("========================\r\n");

    /* reset batch */
    zero_buf();
    last_run_ms = now_ms;
    return 1;
}

/* accessor */
void pca_prune_get_serialized_payload(const uint8_t **ptr, uint16_t *len)
{
    if (ptr) *ptr = ser_buf;
    if (len) *len = ser_len;
}


///*
// * Core/Src/pca_prune.c
// *
// * PCA + pruning module (top-1 PCA) with verbose diagnostics and FFT-prune integration
// * + serialized payload builder for WiFi transmission.
// */
//
//#include "pca_prune.h"
//#include "fft_utils.h"
//#include <string.h>
//#include <stdio.h>
//#include <math.h>
//#include "usart.h"
//extern UART_HandleTypeDef huart3;
//
//#include <stdarg.h>
//
///* ----------------------------------------------------------------------------------
// *   dbg_print (you already rely on this; we keep it same)
// * ---------------------------------------------------------------------------------- */
//void dbg_print(const char *fmt, ...) {
//    char buf[256];
//    va_list args;
//    va_start(args, fmt);
//    vsnprintf(buf, sizeof(buf), fmt, args);
//    va_end(args);
//    HAL_UART_Transmit(&huart3, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
//}
//
///* Expect dbg_print implemented in main.c (blocking via huart3) */
//extern void dbg_print(const char *fmt, ...);
//
///* ----------------------------------------------------------------------------------
// *  Internal data
// * ---------------------------------------------------------------------------------- */
//static float data_buf[BATCH_M][N_VARS];
//static int sample_count = 0;
//
///* ----------------------------------------------------------------------------------
// *  Serialization Buffer (NEW)
// * ---------------------------------------------------------------------------------- */
//#ifndef PCA_PRUNE_MAX_PAYLOAD
//#define PCA_PRUNE_MAX_PAYLOAD 1024
//#endif
//
//static uint8_t last_payload[PCA_PRUNE_MAX_PAYLOAD];
//static uint16_t last_payload_len = 0;
//
///* accessor for main.c */
//void pca_prune_get_serialized_payload(const uint8_t **ptr, uint16_t *len)
//{
//    if (ptr) *ptr = last_payload;
//    if (len) *len = last_payload_len;
//}
//
///* builder (NEW) */
//static void pca_prune_build_serialized_payload(const float *eigvec,
//                                               const float *means,
//                                               const float *scores)
//{
//    uint8_t *p = last_payload;
//
//    /* header */
//    memcpy(p, "PRUN", 4); p += 4;
//    *p++ = 1;                  // version
//    *p++ = (uint8_t)N_VARS;    // number of variables
//
//    uint16_t bm = (uint16_t)BATCH_M;
//    memcpy(p, &bm, 2); p += 2;
//
//    /* quantization scale: find max abs score */
//    float max_abs = 0.f;
//    for (int i = 0; i < BATCH_M; i++) {
//        float v = scores[i];
//        if (v < 0) v = -v;
//        if (v > max_abs) max_abs = v;
//    }
//
//    float scale = (max_abs < 1e-6f) ? 1.f : (max_abs / 30000.f);
//    memcpy(p, &scale, 4); p += 4;
//
//    /* eigvec (float32) */
//    for (int i = 0; i < N_VARS; i++) {
//        float v = eigvec[i];
//        memcpy(p, &v, 4); p += 4;
//    }
//
//    /* means (float32) */
//    for (int i = 0; i < N_VARS; i++) {
//        float v = means[i];
//        memcpy(p, &v, 4); p += 4;
//    }
//
//    /* quantized PC1 time series */
//    for (int i = 0; i < BATCH_M; i++) {
//        float fv = scores[i];
//        int32_t q = (int32_t)roundf(fv / scale);
//        if (q > 32767) q = 32767;
//        if (q < -32768) q = -32768;
//        int16_t qi = (int16_t)q;
//        memcpy(p, &qi, 2); p += 2;
//    }
//
//    last_payload_len = (uint16_t)(p - last_payload);
//
//    dbg_print("[PCA] Serialized payload built: %u bytes\r\n", last_payload_len);
//}
//
///* ----------------------------------------------------------------------------------
// *  Helpers
// * ---------------------------------------------------------------------------------- */
//static void zero_buf(void) {
//    memset(data_buf, 0, sizeof(data_buf));
//    sample_count = 0;
//}
//
///* init */
//void pca_prune_init(void) {
//    zero_buf();
//    dbg_print("[PCA] pca_prune_init: BATCH_M=%d N_VARS=%d\r\n", BATCH_M, N_VARS);
//}
//
///* feed sample */
//void pca_prune_feed_sample(const float sample[N_VARS]) {
//    if (!sample) return;
//    if (sample_count < BATCH_M) {
//        for (int j = 0; j < N_VARS; ++j)
//            data_buf[sample_count][j] = sample[j];
//        sample_count++;
//
//        dbg_print("[PCA] fed sample #%d: [", sample_count);
//        for (int j = 0; j < N_VARS; ++j)
//            dbg_print("%.3f%s", sample[j], (j+1==N_VARS ? "" : ", "));
//        dbg_print("]\r\n");
//    } else {
//        /* rolling replace */
//        memmove(&data_buf[0], &data_buf[1], sizeof(float)*N_VARS*(BATCH_M-1));
//        for (int j = 0; j < N_VARS; j++) data_buf[BATCH_M-1][j] = sample[j];
//        dbg_print("[PCA] buffer full: rolling\r\n");
//    }
//}
//
///* mean */
//static void compute_means(float means[N_VARS]) {
//    for (int j = 0; j < N_VARS; j++) means[j] = 0.f;
//    if (sample_count <= 0) return;
//
//    for (int t = 0; t < sample_count; t++)
//        for (int j = 0; j < N_VARS; j++)
//            means[j] += data_buf[t][j];
//
//    float inv = 1.f / sample_count;
//    for (int j = 0; j < N_VARS; j++) means[j] *= inv;
//}
//
///* covariance */
//static void compute_covariance(const float means[N_VARS], float cov[N_VARS][N_VARS]) {
//    for (int i = 0; i < N_VARS; i++)
//        for (int j = 0; j < N_VARS; j++)
//            cov[i][j] = 0.f;
//
//    if (sample_count < 2) return;
//
//    for (int t = 0; t < sample_count; t++) {
//        for (int i = 0; i < N_VARS; i++) {
//            float a = data_buf[t][i] - means[i];
//            for (int j = 0; j < N_VARS; j++)
//                cov[i][j] += a * (data_buf[t][j] - means[j]);
//        }
//    }
//
//    float denom = 1.f / (sample_count - 1);
//    for (int i = 0; i < N_VARS; i++)
//        for (int j = 0; j < N_VARS; j++)
//            cov[i][j] *= denom;
//}
//
///* power iteration */
//static void power_iteration_top1(const float cov[N_VARS][N_VARS], float eig[N_VARS]) {
//    for (int i = 0; i < N_VARS; i++) eig[i] = 1.f;
//
//    float norm = 0.f;
//    for (int i = 0; i < N_VARS; i++) norm += eig[i]*eig[i];
//    norm = sqrtf(norm);
//    for (int i = 0; i < N_VARS; i++) eig[i] /= norm;
//
//    for (int it = 0; it < 100; it++) {
//        float y[N_VARS];
//        for (int i = 0; i < N_VARS; i++) {
//            y[i] = 0.f;
//            for (int j = 0; j < N_VARS; j++)
//                y[i] += cov[i][j] * eig[j];
//        }
//        float nrm = 0.f;
//        for (int i = 0; i < N_VARS; i++) nrm += y[i]*y[i];
//        if (nrm < 1e-20f) break;
//        nrm = sqrtf(nrm);
//
//        float diff = 0.f;
//        for (int i = 0; i < N_VARS; i++) {
//            float v = y[i] / nrm;
//            float d = v - eig[i];
//            diff += d*d;
//            eig[i] = v;
//        }
//        if (diff < 1e-12f) break;
//    }
//}
//
///* project */
//static void project_scores(const float means[N_VARS], const float eig[N_VARS], float scores[BATCH_M]) {
//    for (int t = 0; t < sample_count; t++) {
//        float s = 0.f;
//        for (int j = 0; j < N_VARS; j++)
//            s += (data_buf[t][j] - means[j]) * eig[j];
//        scores[t] = s;
//    }
//}
//
///* reconstruct */
//static void reconstruct_from_scores(const float means[N_VARS], const float eig[N_VARS],
//                                    const float scores[BATCH_M],
//                                    float recon[BATCH_M][N_VARS])
//{
//    for (int t = 0; t < sample_count; t++)
//        for (int j = 0; j < N_VARS; j++)
//            recon[t][j] = means[j] + scores[t] * eig[j];
//}
//
///* MSE */
//static float compute_mse_internal(const float recon[BATCH_M][N_VARS]) {
//    double sse = 0.0;
//    for (int t = 0; t < sample_count; t++)
//        for (int j = 0; j < N_VARS; j++) {
//            double d = (double)data_buf[t][j] - (double)recon[t][j];
//            sse += d*d;
//        }
//    double denom = (double)sample_count * (double)N_VARS;
//    if (denom <= 0.0) return 0.f;
//    return (float)(sse / denom);
//}
//
///* total variance */
//static float compute_total_variance(const float means[N_VARS]) {
//    double s = 0.0;
//    for (int t = 0; t < sample_count; t++)
//        for (int j = 0; j < N_VARS; j++) {
//            double d = (double)data_buf[t][j] - (double)means[j];
//            s += d*d;
//        }
//    double denom = (double)sample_count * (double)N_VARS;
//    if (denom <= 0.0) return 0.f;
//    return (float)(s / denom);
//}
//
///* ----------------------------------------------------------------------------------
// * MAIN PCA FUNCTION (returns 1 if PCA run)
// * ---------------------------------------------------------------------------------- */
//int pca_prune_maybe_run_and_report(void)
//{
//    static uint32_t last_run_ms = 0;
//    uint32_t now_ms = HAL_GetTick();
//
//    dbg_print("[PCA] maybe_run: sample_count=%d elapsed=%lums\r\n",
//              sample_count, (unsigned long)(now_ms - last_run_ms));
//
//    if (sample_count < BATCH_M && (now_ms - last_run_ms) < 60000UL) {
//        dbg_print("[PCA] Not running (need full/60s)\r\n");
//        return 0;
//    }
//    if (sample_count < 4) {
//        dbg_print("[PCA] Too few samples\r\n");
//        return 0;
//    }
//
//    dbg_print("[PCA] Running PCA over %d samples\r\n", sample_count);
//
//    /* means */
//    float means[N_VARS];
//    compute_means(means);
//
//    /* covariance */
//    float cov[N_VARS][N_VARS];
//    compute_covariance(means, cov);
//
//    /* eigvec */
//    float eigvec[N_VARS];
//    power_iteration_top1(cov, eigvec);
//
//    /* project -> scores */
//    float scores[BATCH_M];
//    project_scores(means, eigvec, scores);
//
//    /* reconstruct */
//    float recon[BATCH_M][N_VARS];
//    reconstruct_from_scores(means, eigvec, scores, recon);
//
//    float mse = compute_mse_internal(recon);
//    float tot_var = compute_total_variance(means);
//
//    float explained = 0.f;
//    if (tot_var > 1e-12f) explained = 100.f * (1.f - mse / tot_var);
//
//    /* --- Standard PCA report (unchanged) --- */
//    dbg_print("\r\n=== PCA PRUNE REPORT ===\r\n");
//    dbg_print("Samples=%d  N_VARS=%d BATCH_M=%d\r\n", sample_count, N_VARS, BATCH_M);
//
//    dbg_print("eigvec: ");
//    for (int j = 0; j < N_VARS; j++) dbg_print("%.4f ", eigvec[j]);
//    dbg_print("\r\n");
//
//    dbg_print("means:  ");
//    for (int j = 0; j < N_VARS; j++) dbg_print("%.3f ", means[j]);
//    dbg_print("\r\n");
//
//    dbg_print("MSE=%.6f TotVar=%.6f ExplainedVar=%.2f%%\r\n", mse, tot_var, explained);
//
//    /* --- FFT prune section (unchanged) --- */
//    {
//        int16_t qre[MAX_KEEP_BINS];
//        int16_t qim[MAX_KEEP_BINS];
//        int kept_idx[MAX_KEEP_BINS];
//        int kept_n = 0, qbytes = 0;
//        float recon_mse = 0.f;
//
//        int rc = fft_prune(scores, sample_count,
//                           qre, qim, kept_idx, &kept_n, &qbytes, &recon_mse);
//
//        if (rc == 0) {
//            dbg_print("\r\n--- FFT PRUNE ---\r\n");
//            dbg_print("Kept=%d  QuantBytes=%d  ReconMSE=%.6f\r\n", kept_n, qbytes, recon_mse);
//        }
//    }
//
//    dbg_print("[PCA_SUMMARY] MSE=%.6f Explained=%.2f%%\r\n", mse, explained);
//
//    /* =====================================================
//     * === SERIALIZATION ADDED HERE (for WiFi transmission)
//     * ===================================================== */
//    pca_prune_build_serialized_payload(eigvec, means, scores);
//    dbg_print("[PCA] Serialized payload ready for main.c\r\n");
//
//    /* reset batch */
//    zero_buf();
//    last_run_ms = now_ms;
//    return 1;
//}
