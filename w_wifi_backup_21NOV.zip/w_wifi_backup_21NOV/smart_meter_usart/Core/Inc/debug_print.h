#ifndef DEBUG_PRINT_H
#define DEBUG_PRINT_H

#include "main.h"
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>

/* Optional compile-time filter: set to 0 to disable noisy categories */
#define DEBUG_ENABLE_INFO  1
#define DEBUG_ENABLE_DATA  1
#define DEBUG_ENABLE_WARN  1
#define DEBUG_ENABLE_ERR   1

/* Core print function (implemented in debug.c) */
void debug_uart_print(const char *fmt, ...);

/* Optional RTC timestamp print (implemented in debug.c) */
void debug_print_timestamp(void);

/* Basic init (if needed) */
void debug_print_init(void);

/* Hex dump utility */
void print_hex_buf(const uint8_t *buf, unsigned len);

/* ---- Convenience macros ---- */
#if DEBUG_ENABLE_INFO
#  define DBG_INFO(fmt, ...)  debug_uart_print("[INFO] " fmt "\r\n", ##__VA_ARGS__)
#else
#  define DBG_INFO(fmt, ...)
#endif

#if DEBUG_ENABLE_DATA
#  define DBG_DATA(fmt, ...)  debug_uart_print("[DATA] " fmt "\r\n", ##__VA_ARGS__)
#else
#  define DBG_DATA(fmt, ...)
#endif

#if DEBUG_ENABLE_WARN
#  define DBG_WARN(fmt, ...)  debug_uart_print("[WARN] " fmt "\r\n", ##__VA_ARGS__)
#else
#  define DBG_WARN(fmt, ...)
#endif

#if DEBUG_ENABLE_ERR
#  define DBG_ERR(fmt, ...)   debug_uart_print("[ERR]  " fmt "\r\n", ##__VA_ARGS__)
#else
#  define DBG_ERR(fmt, ...)
#endif

#endif /* DEBUG_PRINT_H */
