#ifndef FFT_UTILS_H
#define FFT_UTILS_H

#include "arm_math.h"   // CMSIS DSP
#include <stdint.h>

/* -------------------------------------------------------------------
 *  FFT configuration parameters
 * ------------------------------------------------------------------- */
#define FFT_LEN           64
#define MAX_KEEP_BINS     8
#define ENERGY_THRESHOLD  0.90f

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Perform FFT-based pruning / compression of PCA scores.
 *
 * @param scores: Input float array (time-domain signal or PCA scores)
 * @param len: Length of the input (≤ FFT_LEN)
 * @param qre_out: Quantized real bins output (int16_t)
 * @param qim_out: Quantized imaginary bins output (int16_t)
 * @param kept_bins: Array of indices of kept bins
 * @param n_kept: Number of bins actually kept
 * @param total_bins: Total bins considered
 * @param energy_kept: Fraction of total energy preserved (0–1)
 *
 * @return int 0 = OK, negative on error
 */
int fft_prune(const float *scores, int len,
              int16_t *qre_out, int16_t *qim_out,
              int *kept_bins, int *n_kept,
              int *total_bins, float *energy_kept);

/**
 * @brief Run full FFT compression + quantization + inverse reconstruction.
 */
void run_fft_compress(float *input, int len);

#ifdef __cplusplus
}
#endif

#endif /* FFT_UTILS_H */
