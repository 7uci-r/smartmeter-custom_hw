/*
 * Core/Src/pca_prune.c
 *
 * PCA + pruning module (top-1 PCA) with verbose diagnostics and FFT-prune integration.
 *
 * Expects dbg_print(const char *fmt, ...) implemented in main.c
 */

#include "pca_prune.h"
#include "fft_utils.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "usart.h"
extern UART_HandleTypeDef huart3;

#include <stdarg.h>

void dbg_print(const char *fmt, ...) {
    char buf[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    HAL_UART_Transmit(&huart3, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
}

/* Expect dbg_print implemented in main.c (blocking via huart3) */
extern void dbg_print(const char *fmt, ...);

/* Internal storage */
static float data_buf[BATCH_M][N_VARS];
static int sample_count = 0;

/* helpers */
static void zero_buf(void) {
    memset(data_buf, 0, sizeof(data_buf));
    sample_count = 0;
}

/* init */
void pca_prune_init(void) {
    zero_buf();
    dbg_print("[PCA] pca_prune_init: BATCH_M=%d N_VARS=%d\r\n", BATCH_M, N_VARS);
}

/* copy a sample (N_VARS floats) into internal buffer.
   Diagnostic print added so we can confirm feed operations. */
void pca_prune_feed_sample(const float sample[N_VARS]) {
    if (sample == NULL) return;
    if (sample_count < BATCH_M) {
        for (int j = 0; j < N_VARS; ++j) data_buf[sample_count][j] = sample[j];
        sample_count++;
        dbg_print("[PCA] fed sample #%d: [", sample_count);
        for (int j = 0; j < N_VARS; ++j) dbg_print("%.3f%s", sample[j], (j+1==N_VARS) ? "" : ", ");
        dbg_print("]\r\n");
    } else {
        /* rolling: drop oldest */
        memmove(&data_buf[0], &data_buf[1], sizeof(float) * N_VARS * (BATCH_M - 1));
        for (int j = 0; j < N_VARS; ++j) data_buf[BATCH_M - 1][j] = sample[j];
        dbg_print("[PCA] buffer full -> rolling, still count=%d\r\n", sample_count);
    }
}

/* compute column means */
static void compute_means(float means[N_VARS]) {
    for (int j = 0; j < N_VARS; ++j) means[j] = 0.0f;
    if (sample_count <= 0) return;
    for (int i = 0; i < sample_count; ++i)
        for (int j = 0; j < N_VARS; ++j)
            means[j] += data_buf[i][j];
    float inv = 1.0f / (float)sample_count;
    for (int j = 0; j < N_VARS; ++j) means[j] *= inv;
}

/* compute unbiased covariance matrix (N_VARS x N_VARS) */
static void compute_covariance(const float means[N_VARS], float cov[N_VARS][N_VARS]) {
    for (int i = 0; i < N_VARS; ++i)
        for (int j = 0; j < N_VARS; ++j)
            cov[i][j] = 0.0f;
    if (sample_count < 2) return;
    for (int t = 0; t < sample_count; ++t) {
        for (int i = 0; i < N_VARS; ++i) {
            float a = data_buf[t][i] - means[i];
            for (int j = 0; j < N_VARS; ++j) {
                float b = data_buf[t][j] - means[j];
                cov[i][j] += a * b;
            }
        }
    }
    float denom = 1.0f / (float)(sample_count - 1);
    for (int i = 0; i < N_VARS; ++i)
        for (int j = 0; j < N_VARS; ++j)
            cov[i][j] *= denom;
}

/* power iteration (top-1 eigenvector) */
static void power_iteration_top1(const float cov[N_VARS][N_VARS], float eig[N_VARS]) {
    /* initialize */
    for (int i = 0; i < N_VARS; ++i) eig[i] = 1.0f; /* simple seed */
    /* normalize seed */
    {
        float s = 0.0f;
        for (int i = 0; i < N_VARS; ++i) s += eig[i]*eig[i];
        s = sqrtf(s); if (s <= 1e-12f) s = 1.0f;
        for (int i = 0; i < N_VARS; ++i) eig[i] /= s;
    }
    /* iterate */
    for (int it = 0; it < 100; ++it) {
        float y[N_VARS];
        for (int i = 0; i < N_VARS; ++i) { y[i] = 0.0f; for (int j = 0; j < N_VARS; ++j) y[i] += cov[i][j] * eig[j]; }
        /* norm */
        float norm = 0.0f;
        for (int i = 0; i < N_VARS; ++i) norm += y[i]*y[i];
        if (norm <= 1e-20f) break;
        norm = sqrtf(norm);
        /* compute difference to check convergence */
        float diff = 0.0f;
        for (int i = 0; i < N_VARS; ++i) {
            float v = y[i]/norm;
            float d = v - eig[i];
            diff += d*d;
            eig[i] = v;
        }
        if (diff < 1e-12f) break;
    }
}

/* project to top-1 component to get scores */
static void project_scores(const float means[N_VARS], const float eig[N_VARS], float scores[BATCH_M]) {
    for (int t = 0; t < sample_count; ++t) {
        float s = 0.0f;
        for (int j = 0; j < N_VARS; ++j) s += (data_buf[t][j] - means[j]) * eig[j];
        scores[t] = s;
    }
}

/* reconstruct from scores */
static void reconstruct_from_scores(const float means[N_VARS], const float eig[N_VARS], const float scores[BATCH_M], float recon[BATCH_M][N_VARS]) {
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j)
            recon[t][j] = means[j] + scores[t] * eig[j];
}

/* compute MSE between data_buf and recon */
static float compute_mse_internal(const float recon[BATCH_M][N_VARS]) {
    double sse = 0.0;
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j) {
            double d = (double)data_buf[t][j] - (double)recon[t][j];
            sse += d * d;
        }
    double denom = (double)sample_count * (double)N_VARS;
    if (denom <= 0.0) return 0.0f;
    return (float)(sse / denom);
}

/* compute total variance of original data (used to estimate savings) */
static float compute_total_variance(const float means[N_VARS]) {
    double s = 0.0;
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j) {
            double d = (double)data_buf[t][j] - (double)means[j];
            s += d*d;
        }
    double denom = (double)sample_count * (double)N_VARS;
    if (denom <= 0.0) return 0.0f;
    return (float)(s / denom);
}

/* The main public function: if enough samples accumulated, run PCA, print report, reset buffer.
   Adds diagnostics for sample_count and time-based trigger. */
int pca_prune_maybe_run_and_report(void) {
    static uint32_t last_run_ms = 0;
    uint32_t now_ms = HAL_GetTick();

    dbg_print("[PCA] maybe_run called: sample_count=%d last_run=%lu now=%lu elapsed=%lu\r\n",
              sample_count, (unsigned long)last_run_ms, (unsigned long)now_ms, (unsigned long)(now_ms - last_run_ms));

    /* Trigger if buffer is full OR 60s passed since last run and we have at least some samples */
    if (sample_count < BATCH_M && (now_ms - last_run_ms) < 60000UL) {
        dbg_print("[PCA] Not running: sample_count=%d elapsed=%lums (need %d or 60000ms)\r\n",
                  sample_count, (unsigned long)(now_ms - last_run_ms), BATCH_M);
        return 0;
    }
    if (sample_count < 4) {
        dbg_print("[PCA] Not enough samples to run PCA (have %d)\r\n", sample_count);
        return 0;
    }

    dbg_print("[PCA] Running PCA with %d samples (forced by timer/full)\r\n", sample_count);

    /* 1) Means */
    float means[N_VARS];
    compute_means(means);

    /* 2) Covariance */
    float cov[N_VARS][N_VARS];
    compute_covariance(means, cov);

    /* 3) Top-1 eigvec */
    float eigvec[N_VARS];
    power_iteration_top1(cov, eigvec);

    /* 4) Project -> scores */
    float scores[BATCH_M];
    project_scores(means, eigvec, scores);

    /* 5) Reconstruct & MSE */
    float recon[BATCH_M][N_VARS];
    reconstruct_from_scores(means, eigvec, scores, recon);
    float mse = compute_mse_internal(recon);

    /* 6) total variance and savings estimate */
    float tot_var = compute_total_variance(means);
    float savings_pct = 0.0f;
    if (tot_var > 1e-12f) savings_pct = (1.0f - (mse / tot_var)) * 100.0f;
    if (savings_pct < 0.0f) savings_pct = 0.0f;

    /* 7) Print detailed PCA report */
    dbg_print("\r\n=== PCA PRUNE REPORT ===\r\n");
    dbg_print("Samples: %d  N_VARS: %d  BATCH_M: %d\r\n", sample_count, N_VARS, BATCH_M);

    // Eigenvector (direction of maximum variance)
    dbg_print("eigvec: ");
    for (int j = 0; j < N_VARS; ++j) dbg_print("%.4f ", eigvec[j]);
    dbg_print("\r\n");

    // Means (centroid)
    dbg_print("means:  ");
    for (int j = 0; j < N_VARS; ++j) dbg_print("%.3f ", means[j]);
    dbg_print("\r\n");

    // Core metrics
    dbg_print("MSE=%.6f  TotVar=%.6f  EstimatedSavings=%.2f%%\r\n",
              mse, tot_var, savings_pct);

    // --- Additional breakdown ---
    // variance captured ratio (explained variance)
    float explained_ratio = 0.0f;
    if (tot_var > 1e-9f) explained_ratio = 100.0f * (1.0f - mse / tot_var);

    // Raw data size vs projected data size (approx)
    const int raw_bytes = sample_count * N_VARS * sizeof(float);
    const int pca_bytes = sample_count * sizeof(float); // top-1 projection (scores)
    float pca_savings = 100.0f * (1.0f - ((float)pca_bytes / (float)raw_bytes));

    dbg_print("\r\n--- PCA Compression Estimates ---\r\n");
    dbg_print("RawBytes=%d  PCA_1D_Bytes=%d  Savings=%.2f%%  ExplainedVar=%.2f%%\r\n",
              raw_bytes, pca_bytes, pca_savings, explained_ratio);

    // Per-variable reconstruction errors (RMS)
    dbg_print("\r\nPer-variable RMS reconstruction errors:\r\n");
    for (int j = 0; j < N_VARS; ++j) {
        double se = 0.0;
        for (int t = 0; t < sample_count; ++t) {
            double d = (double)data_buf[t][j] - (double)recon[t][j];
            se += d * d;
        }
        float rms = 0.0f;
        if (sample_count > 0) rms = sqrtf(se / sample_count);
        dbg_print("Var[%d]: RMS=%.6f  mean=%.3f\r\n", j, rms, means[j]);
    }

    // Top projection min/max range (for quantization preview)
    float smin = scores[0], smax = scores[0];
    for (int t = 1; t < sample_count; ++t) {
        if (scores[t] < smin) smin = scores[t];
        if (scores[t] > smax) smax = scores[t];
    }
    dbg_print("\r\nScores range: min=%.3f  max=%.3f  span=%.3f\r\n", smin, smax, smax - smin);

    /* === FFT-based pruning of the top-1 scores (compressive sensing) === */
    {
        int16_t qre[MAX_KEEP_BINS];
        int16_t qim[MAX_KEEP_BINS];
        int kept_idx[MAX_KEEP_BINS];
        int kept_n = 0;
        int qbytes = 0;
        float recon_mse = 0.0f;

        int rc = fft_prune(scores, sample_count,
                           qre, qim, kept_idx, &kept_n,
                           &qbytes, &recon_mse);
        if (rc == 0) {
            dbg_print("\r\n--- FFT PRUNE (scores) ---\r\n");
            dbg_print("Kept bins: %d  QuantBytes=%d  ReconMSE=%.6f\r\n", kept_n, qbytes, recon_mse);
            dbg_print("Indices: ");
            for (int i = 0; i < kept_n; ++i) dbg_print("%d ", kept_idx[i]);
            dbg_print("\r\nQuantized (re,im): ");
            for (int i = 0; i < kept_n; ++i) dbg_print("%d,%d ", (int)qre[i], (int)qim[i]);
            dbg_print("\r\n");

            /* realistic compressed bytes accounting (means + eigvec as float32 + quantized bins payload) */
            int bytes_means = N_VARS * 4;
            int bytes_eigvec = N_VARS * 4;
            int total_bytes = bytes_means + bytes_eigvec + qbytes;
            float real_saved = 100.0f * (1.0f - ((float)total_bytes / (float)raw_bytes));
            dbg_print("Bytes: raw=%d compressed(est)=%d saved=%.2f%%\r\n", raw_bytes, total_bytes, real_saved);
        } else {
            dbg_print("[PCA] fft_prune failed rc=%d\r\n", rc);
        }
    }

    /* Compact summary line for quick logs */
    dbg_print("\r\n[PCA_SUMMARY] MSE=%.6f | TotVar=%.6f | Explained=%.2f%% | BytesSaved=%.2f%%\r\n",
              mse, tot_var, explained_ratio, pca_savings);
    dbg_print("========================\r\n");

    /* Reset batch */
    zero_buf();
    last_run_ms = now_ms;
    return 1;
}
