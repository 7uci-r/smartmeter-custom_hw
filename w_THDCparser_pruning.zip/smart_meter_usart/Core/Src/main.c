/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : THDC parser + PCA pruning integration + RTC diagnostics
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "dma.h"
#include "usart.h"
#include "usb_otg.h"
#include "gpio.h"
#include "fft_utils.h"


#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>

#include "pca_prune.h"  /* pca_prune_feed_sample(), pca_prune_maybe_run_and_report() */

#define HAVE_PCA_PRUNE 1

/* THDC frame constants */
#define FRAME_TOTAL_LEN   46
#define FRAME_PAYLOAD_LEN 39
#define FRAME_HEADER0 'T'
#define FRAME_HEADER1 'H'
#define FRAME_HEADER2 'D'
#define FRAME_HEADER3 'C'

#ifndef RX_DMA_BUF_LEN
#define RX_DMA_BUF_LEN 128
#endif

/* extern DMA rx buffer (from usart.c) */
extern volatile uint8_t rx_dma_buf[RX_DMA_BUF_LEN];

/* parser state variables */
static uint8_t frame_buf[FRAME_TOTAL_LEN];
static size_t frame_idx = 0;
static int parser_state = 0;
static uint16_t dma_last_pos = 0;

/* parsed measurement variables */
static volatile float parsed_voltage = 0.0f;
static volatile float parsed_current = 0.0f;
static volatile float parsed_frequency = 0.0f;
static volatile float parsed_apparent = 0.0f;
static volatile float parsed_active = 0.0f;
static volatile float parsed_pf = 0.0f;
static volatile char  parsed_pfSign = ' ';

/* parsed timestamp from frame */
static volatile uint8_t parsed_day = 0;
static volatile uint8_t parsed_month = 0;
static volatile uint8_t parsed_year_off = 0;
static volatile uint8_t parsed_hour = 0;
static volatile uint8_t parsed_minute = 0;
static volatile uint8_t parsed_second = 0;

/* flags */
static volatile uint8_t frame_ready_flag = 0;

/* simple UART3 debug printf */
static void dbg_print(const char *fmt, ...)
{
    char tmp[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n > 0) {
        uint16_t len = (uint16_t)((n < (int)sizeof(tmp)) ? n : (int)sizeof(tmp)-1);
        HAL_UART_Transmit(&huart3, (uint8_t *)tmp, len, HAL_MAX_DELAY);
    }
}

/* CRC helper */
static uint16_t crc16_modbus(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t pos = 0; pos < len; pos++) {
        crc ^= data[pos];
        for (uint8_t i = 0; i < 8; i++) {
            if (crc & 0x0001) crc = (crc >> 1) ^ 0xA001;
            else crc >>= 1;
        }
    }
    return crc;
}

/* big-endian helpers */
static uint32_t read_u32_be(const uint8_t *p) { return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3]; }
static uint16_t read_u16_be(const uint8_t *p) { return (uint16_t)((p[0]<<8)|p[1]); }

/* parser */
static void parser_feed_byte(uint8_t b)
{
    switch (parser_state) {
    case 0:
        if (b == FRAME_HEADER0) { frame_buf[0] = b; frame_idx = 1; parser_state = 1; }
        break;
    case 1:
        if (frame_idx == 1 && b == FRAME_HEADER1) { frame_buf[frame_idx++] = b; parser_state = 2; }
        else { parser_state = (b == FRAME_HEADER0) ? 1 : 0; frame_idx = (parser_state)?1:0; }
        break;
    case 2:
        if (b == FRAME_HEADER2) { frame_buf[frame_idx++] = b; parser_state = 3; }
        else { parser_state = (b == FRAME_HEADER0)?1:0; frame_idx = (parser_state)?1:0; }
        break;
    case 3:
        if (b == FRAME_HEADER3) { frame_buf[frame_idx++] = b; parser_state = 4; }
        else { parser_state = (b == FRAME_HEADER0)?1:0; frame_idx = (parser_state)?1:0; }
        break;
    case 4:
        frame_buf[frame_idx++] = b;
        if (b != FRAME_PAYLOAD_LEN) { parser_state = 0; frame_idx = 0; }
        else parser_state = 5;
        break;
    case 5:
        frame_buf[frame_idx++] = b;
        if (frame_idx >= FRAME_TOTAL_LEN) {
            uint16_t crc_calc = crc16_modbus(&frame_buf[5], FRAME_PAYLOAD_LEN);
            uint16_t crc_rx = ((uint16_t)frame_buf[44] << 8) | frame_buf[45];
            if (crc_calc == crc_rx) {
                const uint8_t *pl = &frame_buf[5];
                uint32_t voltage_mV    = read_u32_be(&pl[0]);
                uint32_t current_mA    = read_u32_be(&pl[4]);
                uint32_t realPower_w   = read_u32_be(&pl[8]);
                uint32_t apparentPower = read_u32_be(&pl[16]);
                uint16_t instPF_raw    = read_u16_be(&pl[20]);
                char pfSign            = (char)pl[22];
                uint16_t freq_raw      = read_u16_be(&pl[23]);
                uint8_t day            = pl[33];
                uint8_t month          = pl[34];
                uint8_t year_off       = pl[35];
                uint8_t hour           = pl[36];
                uint8_t minute         = pl[37];
                uint8_t second         = pl[38];

                parsed_voltage   = ((float)voltage_mV)/1000.0f;
                parsed_current   = ((float)current_mA)/1000.0f;
                parsed_active    = (float)realPower_w;
                parsed_apparent  = (float)apparentPower;
                parsed_pf        = ((float)instPF_raw)/100.0f;
                parsed_pfSign    = pfSign;
                parsed_frequency = ((float)freq_raw)/100.0f;

                parsed_day       = day;
                parsed_month     = month;
                parsed_year_off  = year_off;
                parsed_hour      = hour;
                parsed_minute    = minute;
                parsed_second    = second;

                frame_ready_flag = 1;
            }
            parser_state = 0; frame_idx = 0;
        }
        break;
    default: parser_state = 0; frame_idx = 0; break;
    }
}

/* poll DMA ring buffer */
static void parser_poll_dma(void)
{
    if (huart2.hdmarx == NULL) return;
    uint16_t new_pos = (uint16_t)(RX_DMA_BUF_LEN - __HAL_DMA_GET_COUNTER(huart2.hdmarx));
    if (new_pos != dma_last_pos) {
        if (new_pos > dma_last_pos)
            for (uint16_t i = dma_last_pos; i < new_pos; ++i) parser_feed_byte(rx_dma_buf[i]);
        else {
            for (uint16_t i = dma_last_pos; i < RX_DMA_BUF_LEN; ++i) parser_feed_byte(rx_dma_buf[i]);
            for (uint16_t i = 0; i < new_pos; ++i) parser_feed_byte(rx_dma_buf[i]);
        }
        dma_last_pos = new_pos;
    }
}

/* main */
int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_USART3_UART_Init(); /* debug */
    MX_USB_OTG_FS_PCD_Init();
    MX_USART2_UART_Init(); /* meter UART */

    dbg_print("\r\n[BOOT] THDC + PCA + RTC print active\r\n");

#ifdef HAVE_PCA_PRUNE
    pca_prune_init();
#endif

    HAL_UART_Receive_DMA(&huart2, (uint8_t*)rx_dma_buf, RX_DMA_BUF_LEN);
    dma_last_pos = (uint16_t)(RX_DMA_BUF_LEN - __HAL_DMA_GET_COUNTER(huart2.hdmarx));

    dbg_print("DMA RX started (%u bytes)\r\n", RX_DMA_BUF_LEN);

    uint32_t last_rtc_print_ms = 0;

    while (1) {
        parser_poll_dma();

        /* Print RTC time every second regardless of frame parsing */
        uint32_t now = HAL_GetTick();
        if (now - last_rtc_print_ms >= 1000) {
            last_rtc_print_ms = now;
            dbg_print("[RTC] %02u-%02u-20%02u %02u:%02u:%02u\r\n",
                      parsed_day, parsed_month, parsed_year_off,
                      parsed_hour, parsed_minute, parsed_second);
        }

        if (frame_ready_flag) {
            frame_ready_flag = 0;

            float voltage  = parsed_voltage * 10.0f;
            float current  = parsed_current;
            float freq     = parsed_frequency * 10.0f;
            float apparent = parsed_apparent;
            float active   = parsed_active;
            float pf       = parsed_pf;
            char pfSign    = parsed_pfSign;

            dbg_print("[DATA] %02u-%02u-20%02u %02u:%02u:%02u | "
                      "V=%.2f I=%.3f P=%.1f PF=%c%.2f F=%.2f\r\n",
                      parsed_day, parsed_month, parsed_year_off,
                      parsed_hour, parsed_minute, parsed_second,
                      voltage, current, active, pfSign, pf, freq);

#if N_VARS >= 6
            float sample[N_VARS] = { current, voltage, active, apparent, pf, freq };
#else
            float sample[6] = { current, voltage, active, apparent, pf, freq };
#endif

#ifdef HAVE_PCA_PRUNE
            pca_prune_feed_sample(sample);
            pca_prune_maybe_run_and_report();
#endif
        }
        HAL_Delay(1);
    }
}

/* clock config (use your working version) */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 384;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|
                                RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3);
}

void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}
