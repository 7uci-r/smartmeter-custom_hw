#ifndef PCA_PRUNE_H
#define PCA_PRUNE_H

#include <stdint.h>

/* Keep these consistent with your main project */
#ifndef N_VARS
#define N_VARS 6   /* current, voltage, active, apparent, pf, freq */
#endif

#ifndef BATCH_M
#define BATCH_M 60
#endif

/* Public API - used by main.c */
void pca_prune_init(void);
void pca_prune_feed_sample(const float sample[N_VARS]);

/* Run pruning when enough samples accumulated. If run, it prints report via dbg_print()
   and resets the internal batch. Returns 1 if run, 0 otherwise. */
int pca_prune_maybe_run_and_report(void);

#endif /* PCA_PRUNE_H */
