#ifndef FFT_UTILS_H
#define FFT_UTILS_H

#include "arm_math.h"   // CMSIS DSP
#include <stdint.h>

/* -------------------------------------------------------------------
 *  FFT configuration parameters
 * ------------------------------------------------------------------- */
#define FFT_LEN           64
#define MAX_KEEP_BINS     8
#define ENERGY_THRESHOLD  0.90f

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Perform FFT-based pruning / compression of PCA scores.
 *
 * @param scores: Input float array (time-domain signal or PCA scores)
 * @param len: Length of the input (≤ FFT_LEN)
 * @param qre_out: Quantized real bins output (int16_t)
 * @param qim_out: Quantized imaginary bins output (int16_t)
 * @param kept_bins: Array of indices of kept bins
 * @param n_kept: Number of bins actually kept
 * @param total_bins: Total bins considered
 * @param energy_kept: Fraction of total energy preserved (0–1)
 *
 * @return int 0 = OK, negative on error
 */
int fft_prune(const float *scores, int len,
              int16_t *qre_out, int16_t *qim_out,
              int *kept_bins, int *n_kept,
              int *total_bins, float *energy_kept);

/**
 * @brief Run full FFT compression + quantization + inverse reconstruction.
 */
void run_fft_compress(float *input, int len);

#ifdef __cplusplus
}
#endif

#endif /* FFT_UTILS_H */


//#ifndef FFT_UTILS_H__
//#define FFT_UTILS_H__
//
//#include <stdint.h>
//
///*
// * fft_prune
// *
// * Inputs:
// *   scores[len]         - real-valued principal component scores (len = sample_count)
// *   len                 - number of valid samples (<= BATCH_M)
// *
// * Outputs:
// *   kept_bins[out_n]    - indices of kept frequency bins (0..FFT_LEN-1)
// *   out_n               - pointer to int, number of kept bins returned
// *   out_qre[out_n]      - quantized real parts (int16) for each kept bin
// *   out_qim[out_n]      - quantized imag parts (int16) for each kept bin
// *   out_qbytes          - pointer to int, number of bytes required to store quantized bins (filled)
// *   out_recon_mse       - pointer to float, MSE between reconstructed PC (first len samples) and original scores
// *
// * Returns 0 on success, <0 on failure.
// *
// * Notes:
// *  - Implementation currently uses an O(N^2) direct DFT for portability.
// *  - FFT_LEN is fixed to 64 (power-of-two >= typical BATCH_M=60). You may change FFT_LEN if needed.
// */
//int fft_prune(const float *scores, int len,
//              int16_t *out_qre, int16_t *out_qim, int *kept_bins, int *out_n,
//              int *out_qbytes, float *out_recon_mse);
//
//#endif /* FFT_UTILS_H__ */
