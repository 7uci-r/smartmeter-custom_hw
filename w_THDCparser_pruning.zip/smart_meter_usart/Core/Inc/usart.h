/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the USART peripherals and the shared RX DMA buffer.
  ******************************************************************************
  */
/* USER CODE END Header */
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"

/* RX DMA buffer size (used by main.c parser) */
#ifndef RX_DMA_BUF_LEN
#define RX_DMA_BUF_LEN 128
#endif

/* Exposed UART handles (definition in usart.c) */
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern DMA_HandleTypeDef hdma_usart2_rx;

/* RX DMA buffer: defined in usart.c, extern here for other modules */
extern volatile uint8_t rx_dma_buf[RX_DMA_BUF_LEN];

/* Init functions */
void MX_USART2_UART_Init(void);
void MX_USART3_UART_Init(void);

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */
