#ifndef UART_READER_H
#define UART_READER_H

#include <stdint.h>
#include <stddef.h>
#include "stm32f4xx_hal.h"

/* Frame constants according to your spec */
#define FRAME_MARKER0 'T'
#define FRAME_MARKER1 'H'
#define FRAME_MARKER2 'D'
#define FRAME_MARKER3 'C'
#define PAYLOAD_LEN   39
#define FRAME_LEN     (4 + 1 + PAYLOAD_LEN + 2)  /* 46 bytes total */

/* Payload buffer consumer API */
void uart_reader_init(UART_HandleTypeDef *huart, DMA_HandleTypeDef *hdma);
void uart_reader_start_dma(void);
void uart_reader_process_dma_buffer(void); /* call from RxCplt handler */
int  uart_reader_frame_available(void);
void uart_reader_get_payload(uint8_t out_payload[PAYLOAD_LEN]); /* consumes available frame */

/* debug helper: call to print last raw frame (optional) */
void uart_reader_print_last_frame_hex(void);

#endif /* UART_READER_H */
