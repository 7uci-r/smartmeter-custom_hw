/*
 * arm_bitreversal_32.c
 *
 *  Created on: Oct 31, 2025
 *      Author: IOT_IIT
 */


#include "dsp/transform_functions.h"

/* ----------------------------------------------------------------------
 * Project:      CMSIS DSP Library
 * Title:        arm_bitreversal_32.c
 * Description:  Bit reversal for 32-bit data types (used internally)
 * -------------------------------------------------------------------- */

void arm_bitreversal_32(
    uint32_t *pSrc,
    uint16_t bitRevFactor,
    uint16_t fftLen,
    const uint16_t *pBitRevTab)
{
    uint32_t i, j, temp;
    j = 0U;

    for (i = 0U; i < fftLen; i++)
    {
        if (i < j)
        {
            temp = pSrc[i];
            pSrc[i] = pSrc[j];
            pSrc[j] = temp;
        }

        /* get next j from bit reversal table */
        j = *pBitRevTab;
        pBitRevTab += bitRevFactor;
    }
}
