#ifndef FFT_UTILS_H
#define FFT_UTILS_H

#include <stdint.h>

#define FFT_LEN           64
#define MAX_KEEP_BINS     8
#define ENERGY_THRESHOLD  0.90f

#if USE_HALF_SPECTRUM
#define FFT_NBINS (FFT_LEN/2 + 1)
#else
#define FFT_NBINS (FFT_LEN)
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint16_t kept_idx[MAX_KEEP_BINS];
    int kept_n;
    int16_t qre[MAX_KEEP_BINS];
    int16_t qim[MAX_KEEP_BINS];
    float quant_scale;
    float mse;
} FFTPruneResult;

int fft_prune(const float *scores, int len,
              int max_keep_bins, float energy_th,
              FFTPruneResult *res);

#ifdef __cplusplus
}
#endif

#endif
