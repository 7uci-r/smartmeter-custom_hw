#ifndef ESP_COMM_H
#define ESP_COMM_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Public APIs (used by your main.c) */
bool esp_check_module(uint32_t timeout_ms);
bool esp_init_wifi_verbose(const char *ssid, const char *password, uint32_t timeout_ms);

/* Persistent TCP APIs */
bool esp_tcp_open_persistent(const char *ip, int port, uint32_t timeout_ms);
bool esp_tcp_send_persistent(const uint8_t *data, uint16_t len, uint32_t timeout_ms);
void esp_tcp_close_persistent(uint32_t timeout_ms);

/* Legacy/compat (kept if you want explicit non-persistent helpers) */
bool esp_tcp_connect_verbose(const char *ip, int port, uint32_t timeout_ms);
bool esp_tcp_send_verbose(const uint8_t *data, uint16_t len, uint32_t timeout_ms);
void esp_tcp_close_verbose(uint32_t timeout_ms);

#ifdef __cplusplus
}
#endif

#endif /* ESP_COMM_H */






//#ifndef ESP_COMM_H
//#define ESP_COMM_H
//
//#include <stdint.h>
//#include <stdbool.h>
//
//#ifdef __cplusplus
//extern "C" {
//#endif
//
///* Initialize WiFi (joins SSID). Returns true if GOT IP (or joined). */
//bool esp_init_basic(const char *ssid, const char *password, uint32_t timeout_ms);
//
///* Connect -> send -> close in a single call. Returns true on SEND OK */
//bool esp_send_dummy(const char *ip, uint16_t port,
//                    const uint8_t *data, uint16_t len,
//                    uint32_t timeout_ms);
//
///* Utility: basic module check (AT + AT+GMR) */
//bool esp_check_module(uint32_t timeout_ms);
//
//#ifdef __cplusplus
//}
//#endif
//
//#endif /* ESP_COMM_H */


//#ifndef ESP_COMM_H
//#define ESP_COMM_H
//
//#include <stdint.h>
//#include <stdbool.h>
//#include "usart.h"
//
///* Blocking AT-based helpers for ESP-01 on huart5 (UART5) */
//
///* Initialize and join WiFi AP (blocking) */
//bool esp_init_wifi(const char *ssid, const char *password, uint32_t timeout_ms);
//
///* Establish TCP connection to IP:port (blocking) */
//bool esp_tcp_connect(const char *ip, int port, uint32_t timeout_ms);
//
///* Send raw binary payload over already-opened TCP connection (blocking).
//   Returns true if "SEND OK" observed. */
//bool esp_tcp_send(const uint8_t *data, uint16_t len, uint32_t timeout_ms);
//
///* Close TCP connection (non-fatal if fails) */
//void esp_tcp_close(uint32_t timeout_ms);
//
///* Wait for generic OK/READY response (utility) */
//bool esp_wait_for_ok(uint32_t timeout_ms);
//
//#endif /* ESP_COMM_H */
//#ifndef ESP_COMM_H
//#define ESP_COMM_H
//
//#include <stdint.h>
//#include <stdbool.h>
//#include "usart.h"
//
///* Verbose blocking ESP-01 AT wrapper which echoes raw responses to huart3 for debugging.
//   Use this to diagnose WiFi join problems. */
//
//bool esp_init_wifi_verbose(const char *ssid, const char *password, uint32_t timeout_ms);
//bool esp_tcp_connect_verbose(const char *ip, int port, uint32_t timeout_ms);
//bool esp_tcp_send_verbose(const uint8_t *data, uint16_t len, uint32_t timeout_ms);
//void esp_tcp_close_verbose(uint32_t timeout_ms);
//
///* Direct debug helpers */
//bool esp_send_at_and_print(const char *cmd, uint32_t timeout_ms); /* sends cmd, prints raw response to huart3 */
//bool esp_check_module(uint32_t timeout_ms); /* send AT and AT+GMR, print results */
//
//#endif /* ESP_COMM_H */

//#ifndef ESP_COMM_H
//#define ESP_COMM_H
//#include <stdint.h>
//#include <stdbool.h>
//
//bool esp_check_module(uint32_t timeout_ms);
//bool esp_init_wifi_verbose(const char *ssid, const char *pass, uint32_t timeout_ms);
//bool esp_tcp_connect_verbose(const char *ip, int port, uint32_t timeout_ms);
//bool esp_tcp_send_verbose(const uint8_t *data, uint16_t len, uint32_t timeout_ms);
//void esp_tcp_close_verbose(uint32_t timeout_ms);
//bool esp_send_test_payload(const char *ip, int port, const uint8_t *buf, uint16_t len);
//
//#endif /* ESP_COMM_H */

///*
// * esp_comm.h
// *
// *  Created on: Nov 10, 2025
// *      Author: IOT_IIT
// */
//
//#ifndef ESP_COMM_H
//#define ESP_COMM_H
//
//#include <stdint.h>
//
//#ifdef __cplusplus
//extern "C" {
//#endif
//
///* Configure these for your HES */
//#ifndef ESP_HES_IP
//#define ESP_HES_IP "10.167.207.231"   /* replace with your PC IP when known */
//#endif
//#ifndef ESP_HES_PORT
//#define ESP_HES_PORT 5000
//#endif
///* ====== HES connection ======
// * Use your laptop’s IP when it is connected to the same hotspot.
// * To find it: open Command Prompt on your laptop → type `ipconfig`
// * → look under “Wireless LAN adapter” → note the IPv4 Address (e.g. 192.168.43.100)
// */
///* Credentials — set these in esp_comm.c or here (avoid committing secrets) */
//#ifndef ESP_WIFI_SSID
//#define ESP_WIFI_SSID "Redmi Note 13 5G"
//#endif
//#ifndef ESP_WIFI_PASS
//#define ESP_WIFI_PASS "wifirm77"
//#endif
//
///* Public API */
//int esp_init_and_connect(void); /* init AT comms, join AP, open TCP -> returns 0 on success */
//int esp_is_connected(void);     /* 1 if TCP connected, 0 otherwise */
//int esp_send_payload(const uint8_t *buf, int len); /* send binary payload over TCP, returns 0 on success */
//void esp_close_connection(void);
//
//#ifdef __cplusplus
//}
//#endif
//
//#endif /* ESP_COMM_H */
