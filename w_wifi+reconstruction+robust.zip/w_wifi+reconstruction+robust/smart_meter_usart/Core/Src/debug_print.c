#include "debug.h"
#include "usart.h"
#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdarg.h>   // for va_start, va_end
#include <stdio.h>    // for vsnprintf
#include "usart.h"    // for HAL_UART_Transmit if not already

void debug_print_init(void)
{
    /* Nothing special yet, but could init mutex or buffers here */
}

/* Core UART printf */
void debug_uart_print(const char *fmt, ...)
{
    char tmp[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n > 0) {
        uint16_t len = (uint16_t)((n < (int)sizeof(tmp)) ? n : (int)sizeof(tmp)-1);
        HAL_UART_Transmit(&huart3, (uint8_t *)tmp, len, HAL_MAX_DELAY);
    }
}

/* Print current timestamp (RTC if available, else HAL_GetTick) */
void debug_print_timestamp(void)
{
#ifdef HAL_RTC_MODULE_ENABLED
    RTC_TimeTypeDef sTime;
    RTC_DateTypeDef sDate;
    HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
    HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
    debug_uart_print("[RTC] %02d:%02d:%02d\r\n", sTime.Hours, sTime.Minutes, sTime.Seconds);
#else
    uint32_t ms = HAL_GetTick();
    uint32_t sec = ms / 1000U;
    uint32_t min = (sec / 60U) % 60U;
    uint32_t hr  = (sec / 3600U) % 24U;
    debug_uart_print("[TICK] %02lu:%02lu:%02lu\r\n", hr, min, sec % 60U);
#endif
}

/* Hex dump */
void print_hex_buf(const uint8_t *buf, unsigned len)
{
    for (unsigned i = 0; i < len; i++) {
        debug_uart_print("%02X ", buf[i]);
        if ((i % 16U) == 15U) debug_uart_print("\r\n");
    }
    debug_uart_print("\r\n");
}
