/*
 * esp_payload.c
 *
 *  Created on: Nov 10, 2025
 *      Author: IOT_IIT
 */
#include "esp_payload.h"
#include <string.h>
#include <stdint.h>
#include "crc_utils.h"

/* Use your existing crc16_modbus if present in project; declare extern to reuse.
   If you prefer, copy paste the crc16_modbus implementation here.
*/
extern uint16_t crc16_modbus(const uint8_t *data, uint16_t len);

int build_pruned_payload(uint8_t *buf, int buf_sz,
                         uint16_t batch_id, uint32_t timestamp,
                         uint8_t sample_count, uint8_t n_vars,
                         const float means[], const float eigvec[],
                         int n_bins, const uint8_t bins_idx[],
                         const int16_t qre[], const int16_t qim[],
                         float scale)
{
    if (buf == NULL) return -1;
    int needed = 1 + 2 + 4 + 1 + 1; // ver + batch + ts + sample_count + n_vars
    needed += n_vars * 4; // means
    needed += n_vars * 4; // eigvec
    needed += 1; // n_bins
    needed += n_bins * 5; // per bin: idx(1) + qre(2) + qim(2)
    needed += 4; // scale
    needed += 2; // crc
    if (needed > buf_sz) return -1;

    uint8_t *p = buf;
    *p++ = 1; /* version */
    memcpy(p, &batch_id, 2); p += 2;
    memcpy(p, &timestamp, 4); p += 4;
    *p++ = sample_count;
    *p++ = n_vars;

    for (int i = 0; i < n_vars; ++i) {
        float v = means[i];
        memcpy(p, &v, 4); p += 4;
    }
    for (int i = 0; i < n_vars; ++i) {
        float v = eigvec[i];
        memcpy(p, &v, 4); p += 4;
    }
    *p++ = (uint8_t)n_bins;
    for (int i = 0; i < n_bins; ++i) {
        *p++ = bins_idx[i];
        int16_t r = qre[i];
        int16_t im = qim[i];
        memcpy(p, &r, 2); p += 2;
        memcpy(p, &im, 2); p += 2;
    }
    memcpy(p, &scale, 4); p += 4;

    uint16_t crc = crc16_modbus(buf, (uint16_t)(p - buf));
    memcpy(p, &crc, 2); p += 2;

    return (int)(p - buf);
}


