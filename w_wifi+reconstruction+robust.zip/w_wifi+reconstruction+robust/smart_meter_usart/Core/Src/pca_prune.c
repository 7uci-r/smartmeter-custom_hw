/* Core/Src/pca_prune.c  (production-ready + Patch A integrated)
 *
 * Patch A adds:
 *  - Correct FFT bin domain validation (FFT_NBINS, not sample_count)
 *  - Updated fft_prune() API using FFTPruneResult
 *  - quant_scale added to payload serialization (float LE)
 *
 * Protocol is still Version = 2 (no break).
 */

#include "pca_prune.h"
#include "fft_utils.h"      // <<< MUST BE PATCH-A VERSION
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdint.h>

#include "usart.h"
extern UART_HandleTypeDef huart3;
extern void dbg_print(const char *fmt, ...);

#ifndef PCA_DEBUG_LEVEL
#define PCA_DEBUG_LEVEL 1
#endif

#ifndef BATCH_M
#error "BATCH_M must be defined"
#endif
#ifndef N_VARS
#error "N_VARS must be defined"
#endif
#ifndef MAX_KEEP_BINS
#error "MAX_KEEP_BINS must be defined"
#endif

/* === Internal buffers === */
static float data_buf[BATCH_M][N_VARS];
static int sample_count = 0;

static uint8_t start_year_off = 0;
static uint8_t start_month = 0;
static uint8_t start_day = 0;
static uint8_t start_hour = 0;
static uint8_t start_min = 0;
static uint8_t start_sec = 0;
static uint16_t start_period_ms = 0;
static int start_ts_set = 0;

/* Serialization buffer */
#define SER_BUF_MAX 512
static uint8_t ser_buf[SER_BUF_MAX];
static uint16_t ser_len = 0;

/* Packet sequence */
static uint16_t ser_seq = 0;

/* CRC16 MODBUS */
static uint16_t crc16_modbus_buf(const uint8_t *data, size_t len)
{
    uint16_t crc = 0xFFFF;
    for (size_t pos=0; pos<len; pos++) {
        crc ^= data[pos];
        for (int i=0; i<8; i++) {
            if (crc & 1) crc = (crc>>1) ^ 0xA001;
            else crc >>= 1;
        }
    }
    return crc;
}

/* Writers */
typedef struct {
    uint8_t *p;
    int rem;
} wr_ctx_t;

static void wr_init(wr_ctx_t *w, uint8_t *buf, int buflen){ w->p=buf; w->rem=buflen; }
static int wr_u8(wr_ctx_t *w,uint8_t v){ if(w->rem<1) return -1; *w->p++=v; w->rem--; return 0; }
static int wr_u16_le(wr_ctx_t *w,uint16_t v){
    if(w->rem<2) return -1;
    *w->p++=(uint8_t)(v&0xFF);
    *w->p++=(uint8_t)((v>>8)&0xFF);
    w->rem-=2;
    return 0;
}
static int wr_i16_le(wr_ctx_t *w,int16_t v){ return wr_u16_le(w,(uint16_t)v); }
static int wr_u32_le(wr_ctx_t *w,uint32_t v){
    if(w->rem<4) return -1;
    *w->p++=(uint8_t)(v&0xFF);
    *w->p++=(uint8_t)((v>>8)&0xFF);
    *w->p++=(uint8_t)((v>>16)&0xFF);
    *w->p++=(uint8_t)((v>>24)&0xFF);
    w->rem-=4;
    return 0;
}
static int wr_f32_le(wr_ctx_t *w,float f){
    union{ float f; uint32_t u; } u;
    u.f=f;
    return wr_u32_le(w,u.u);
}
static int wr_mem(wr_ctx_t *w,const void*src,int len){
    if(w->rem<len) return -1;
    memcpy(w->p,src,len);
    w->p+=len;
    w->rem-=len;
    return 0;
}

/* Reset batch */
static void zero_buf(void){
    memset(data_buf,0,sizeof(data_buf));
    sample_count=0;
}

/* Timestamp set */
void pca_prune_set_start_timestamp(
        uint8_t year_off,uint8_t month,uint8_t day,
        uint8_t hour,uint8_t min,uint8_t sec,
        uint16_t period_ms)
{
    start_year_off=year_off;
    start_month=month;
    start_day=day;
    start_hour=hour;
    start_min=min;
    start_sec=sec;
    start_period_ms=period_ms;
    start_ts_set=1;

#if PCA_DEBUG_LEVEL>=1
    dbg_print("[PCA] start timestamp set\n");
#endif
}

void pca_prune_init(void){
    zero_buf();
#if PCA_DEBUG_LEVEL>=1
    dbg_print("[PCA] pca_prune_init: BATCH_M=%d N_VARS=%d\n",BATCH_M,N_VARS);
#endif
}

void pca_prune_feed_sample(const float sample[N_VARS])
{
    if(!sample) return;
    if(sample_count < BATCH_M){
        memcpy(data_buf[sample_count], sample, sizeof(float)*N_VARS);
        sample_count++;
    } else {
        memmove(&data_buf[0], &data_buf[1],
                sizeof(float)*N_VARS*(BATCH_M-1));
        memcpy(&data_buf[BATCH_M-1], sample, sizeof(float)*N_VARS);
    }
}

/* Means */
static void compute_means(float m[N_VARS]){
    for(int j=0;j<N_VARS;j++) m[j]=0;
    if(sample_count<=0) return;
    for(int t=0;t<sample_count;t++)
        for(int j=0;j<N_VARS;j++)
            m[j]+=data_buf[t][j];
    float inv=1.0f/sample_count;
    for(int j=0;j<N_VARS;j++) m[j]*=inv;
}

/* Covariance */
static void compute_covariance(const float m[N_VARS], float C[N_VARS][N_VARS]){
    memset(C,0,sizeof(float)*N_VARS*N_VARS);
    if(sample_count<2) return;
    for(int t=0;t<sample_count;t++){
        for(int i=0;i<N_VARS;i++){
            float a=data_buf[t][i]-m[i];
            for(int j=0;j<N_VARS;j++){
                float b=data_buf[t][j]-m[j];
                C[i][j]+=a*b;
            }
        }
    }
    float d=1.0f/(sample_count-1);
    for(int i=0;i<N_VARS;i++)
        for(int j=0;j<N_VARS;j++)
            C[i][j]*=d;
}

/* Power iteration */
static void power_iteration_top1(const float C[N_VARS][N_VARS], float eig[N_VARS]){
    for(int i=0;i<N_VARS;i++) eig[i]=1;
    for(int it=0;it<50;it++){
        float y[N_VARS]={0};
        for(int i=0;i<N_VARS;i++)
            for(int j=0;j<N_VARS;j++)
                y[i]+=C[i][j]*eig[j];
        float norm=0;
        for(int i=0;i<N_VARS;i++) norm+=y[i]*y[i];
        if(norm<1e-20f) break;
        norm=sqrtf(norm);
        float diff=0;
        for(int i=0;i<N_VARS;i++){
            float v=y[i]/norm;
            diff+=(v-eig[i])*(v-eig[i]);
            eig[i]=v;
        }
        if(diff<1e-12f) break;
    }
}

/* Project */
static void project_scores(const float m[N_VARS],const float eig[N_VARS],float s[BATCH_M]){
    for(int t=0;t<sample_count;t++){
        float x=0;
        for(int j=0;j<N_VARS;j++) x+=(data_buf[t][j]-m[j])*eig[j];
        s[t]=x;
    }
}
/* reconstruct from scores */
static void reconstruct_from_scores(const float m[N_VARS], const float eig[N_VARS],
                                    const float scores[BATCH_M], float recon[BATCH_M][N_VARS])
{
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j)
            recon[t][j] = m[j] + scores[t] * eig[j];
}

/* compute mse */
static float compute_mse_internal(const float recon[BATCH_M][N_VARS])
{
    double sse = 0.0;
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j) {
            double d = (double)data_buf[t][j] - (double)recon[t][j];
            sse += d * d;
        }
    double denom = (double)sample_count * (double)N_VARS;
    if (denom <= 0.0) return 0.0f;
    return (float)(sse / denom);
}

/* total variance (for explained %) */
static float compute_total_variance(const float means[N_VARS])
{
    double s = 0.0;
    for (int t = 0; t < sample_count; ++t)
        for (int j = 0; j < N_VARS; ++j) {
            double d = (double)data_buf[t][j] - (double)means[j];
            s += d * d;
        }
    double denom = (double)sample_count * (double)N_VARS;
    if (denom <= 0.0) return 0.0f;
    return (float)(s / denom);
}

/* main run function */
int pca_prune_maybe_run_and_report(void)
{
    static uint32_t last_run_ms = 0;
    uint32_t now_ms = HAL_GetTick();

#if PCA_DEBUG_LEVEL >= 2
    dbg_print("[PCA] maybe_run called: sample_count=%d last_run=%lu now=%lu elapsed=%lu\r\n",
              sample_count, (unsigned long)last_run_ms, (unsigned long)now_ms, (unsigned long)(now_ms - last_run_ms));
#endif

    if (sample_count < BATCH_M && (now_ms - last_run_ms) < 60000UL) {
#if PCA_DEBUG_LEVEL >= 1
        dbg_print("[PCA] Not running: sample_count=%d elapsed=%lums (need %d or 60000ms)\r\n",
                  sample_count, (unsigned long)(now_ms - last_run_ms), BATCH_M);
#endif
        return 0;
    }
    if (sample_count < 4) {
#if PCA_DEBUG_LEVEL >= 1
        dbg_print("[PCA] Not enough samples to run PCA (have %d)\r\n", sample_count);
#endif
        return 0;
    }

#if PCA_DEBUG_LEVEL >= 1
    dbg_print("[PCA] Running PCA with %d samples (forced by timer/full)\r\n", sample_count);
#endif

    /* 1) Means */
    float means[N_VARS];
    compute_means(means);

    /* 2) Covariance */
    float cov[N_VARS][N_VARS];
    compute_covariance(means, cov);

    /* 3) Top-1 eigvec */
    float eigvec[N_VARS];
    power_iteration_top1(cov, eigvec);

    /* 4) Project -> scores */
    float scores[BATCH_M];
    project_scores(means, eigvec, scores);

    /* 5) Reconstruct & MSE */
    float recon[BATCH_M][N_VARS];
    reconstruct_from_scores(means, eigvec, scores, recon);
    float mse = compute_mse_internal(recon);

    /* 6) total variance and savings estimate */
    float tot_var = compute_total_variance(means);
    float savings_pct = 0.0f;
    if (tot_var > 1e-12f) savings_pct = (1.0f - (mse / tot_var)) * 100.0f;
    if (savings_pct < 0.0f) savings_pct = 0.0f;

#if PCA_DEBUG_LEVEL >= 2
    dbg_print("\r\n=== PCA PRUNE REPORT ===\r\n");
    dbg_print("Samples: %d  N_VARS: %d  BATCH_M: %d\r\n", sample_count, N_VARS, BATCH_M);
    dbg_print("eigvec: ");
    for (int j = 0; j < N_VARS; ++j) dbg_print("%.4f ", eigvec[j]);
    dbg_print("\r\n");
    dbg_print("means:  ");
    for (int j = 0; j < N_VARS; ++j) dbg_print("%.3f ", means[j]);
    dbg_print("\r\n");
    dbg_print("MSE=%.6f  TotVar=%.6f  EstimatedSavings=%.2f%%\r\n",
              mse, tot_var, savings_pct);
#endif

    /* === FFT prune using Patch-A API === */
    FFTPruneResult fft_res;
    int rc = fft_prune(scores, sample_count, MAX_KEEP_BINS, 0.90f, &fft_res);
    if (rc != 0) {
#if PCA_DEBUG_LEVEL >= 1
        dbg_print("[PCA] fft_prune failed rc=%d\r\n", rc);
#endif
        ser_len = 0;
        zero_buf();
        last_run_ms = now_ms;
        return 1;
    }

#if PCA_DEBUG_LEVEL >= 2
    dbg_print("\r\n--- FFT PRUNE (scores) ---\r\n");
    dbg_print("Kept bins: %d  QuantScale=%.6f  ReconMSE=%.6f\r\n",
              fft_res.kept_n, fft_res.quant_scale, fft_res.mse);
    dbg_print("Indices: ");
    for (int i = 0; i < fft_res.kept_n; ++i) dbg_print("%u ", (unsigned)fft_res.kept_idx[i]);
    dbg_print("\r\nQuantized (re,im): ");
    for (int i = 0; i < fft_res.kept_n; ++i) dbg_print("%d,%d ", (int)fft_res.qre[i], (int)fft_res.qim[i]);
    dbg_print("\r\n");
#endif

    /* compute approximate saved bytes */
    {
        float raw_bytes = (float)sample_count * N_VARS * sizeof(float);
        int bytes_means = N_VARS * 4;
        int bytes_eigvec = N_VARS * 4;
        int bytes_timestamp = 8;
        int qbytes = (2 * fft_res.kept_n) /* idx uint16 */ + (2 * fft_res.kept_n) /* qre */ + (2 * fft_res.kept_n) /* qim */ + 4 /* quant_scale */;
        int total_bytes = bytes_means + bytes_eigvec + qbytes + bytes_timestamp + 2 /* kept_n */;
        float real_saved = 100.0f * (1.0f - ((float)total_bytes / raw_bytes));
        dbg_print("Bytes: raw=%d compressed(est)=%d saved=%.2f%%\r\n", (int)raw_bytes, total_bytes, real_saved);
    }

    /* === SERIALIZE payload (versioned format) === */
    wr_ctx_t w;
    wr_init(&w, ser_buf, SER_BUF_MAX);

    /* magic */
    if (wr_mem(&w, "PCAP", 4) < 0) { dbg_print("[PCA] ser buf overflow (magic)\r\n"); ser_len = 0; goto done; }
    /* version (still 2) */
    if (wr_u8(&w, 2) < 0) { dbg_print("[PCA] ser buf overflow (ver)\r\n"); ser_len = 0; goto done; }

    /* seq */
    uint16_t seq_here = ser_seq++;
    if (wr_u16_le(&w, seq_here) < 0) { dbg_print("[PCA] ser buf overflow (seq)\r\n"); ser_len = 0; goto done; }

    /* reserve payload_len placeholder */
    uint8_t *payload_len_ptr = w.p;
    if (wr_u16_le(&w, 0) < 0) { dbg_print("[PCA] ser buf overflow (payload_len)\r\n"); ser_len = 0; goto done; }

    /* mark body start */
    uint8_t *body_start = w.p;

    /* sample_count */
    if (wr_u16_le(&w, (uint16_t)sample_count) < 0) { ser_len = 0; goto done; }

    /* N_VARS */
    if (wr_u8(&w, (uint8_t)N_VARS) < 0) { ser_len = 0; goto done; }

    /* timestamp (8 bytes) */
    if (wr_u8(&w, start_year_off) < 0) { ser_len = 0; goto done; }
    if (wr_u8(&w, start_month) < 0) { ser_len = 0; goto done; }
    if (wr_u8(&w, start_day) < 0) { ser_len = 0; goto done; }
    if (wr_u8(&w, start_hour) < 0) { ser_len = 0; goto done; }
    if (wr_u8(&w, start_min) < 0) { ser_len = 0; goto done; }
    if (wr_u8(&w, start_sec) < 0) { ser_len = 0; goto done; }
    if (wr_u16_le(&w, start_period_ms) < 0) { ser_len = 0; goto done; }

    /* means */
    for (int j = 0; j < N_VARS; ++j) {
        if (wr_f32_le(&w, means[j]) < 0) { ser_len = 0; goto done; }
    }

    /* eigvec */
    for (int j = 0; j < N_VARS; ++j) {
        if (wr_f32_le(&w, eigvec[j]) < 0) { ser_len = 0; goto done; }
    }

    /* kept_n (uint16 LE) */
    if (wr_u16_le(&w, (uint16_t)fft_res.kept_n) < 0) { ser_len = 0; goto done; }

    /* Validate and write kept_idx[] */
    for (int i = 0; i < fft_res.kept_n; ++i) {
        uint16_t k = fft_res.kept_idx[i];
        /* IMPORTANT: validate against FFT_NBINS (from fft_utils.h) */
#ifdef FFT_NBINS
        if (k >= (uint16_t)FFT_NBINS) {
            dbg_print("[PCA][WARN] kept_idx %u out of domain (max %d). Clamping.\r\n", k, FFT_NBINS - 1);
            k = (uint16_t)(FFT_NBINS - 1);
        }
#else
        /* If FFT_NBINS not defined in header, fallback to sample_count-1 safe clamp */
        if (k >= (uint16_t)sample_count) {
            dbg_print("[PCA][WARN] kept_idx %u out of domain (max %d). Clamping.\r\n", k, sample_count - 1);
            k = (uint16_t)(sample_count - 1);
        }
#endif
        if (wr_u16_le(&w, k) < 0) { ser_len = 0; goto done; }
    }

    /* write qre[] */
    for (int i = 0; i < fft_res.kept_n; ++i) {
        if (wr_i16_le(&w, fft_res.qre[i]) < 0) { ser_len = 0; goto done; }
    }
    /* write qim[] */
    for (int i = 0; i < fft_res.kept_n; ++i) {
        if (wr_i16_le(&w, fft_res.qim[i]) < 0) { ser_len = 0; goto done; }
    }

    /* --- NEW FIELD (Patch A): quant_scale (float LE) --- */
    if (wr_f32_le(&w, fft_res.quant_scale) < 0) { ser_len = 0; goto done; }

    /* compute payload_len and write into placeholder */
    {
        uint16_t payload_len = (uint16_t)(w.p - body_start);
        payload_len_ptr[0] = (uint8_t)(payload_len & 0xFF);
        payload_len_ptr[1] = (uint8_t)((payload_len >> 8) & 0xFF);
    }

    /* CRC over everything up to now */
    {
        size_t crc_len = (size_t)(w.p - ser_buf);
        uint16_t crc = crc16_modbus_buf(ser_buf, crc_len);
        if (wr_u16_le(&w, crc) < 0) { ser_len = 0; goto done; }
    }

    ser_len = (uint16_t)(w.p - ser_buf);

#if PCA_DEBUG_LEVEL >= 1
    dbg_print("[PCA] Serialized payload built: %d bytes (seq=%u payload_len=%u kept_n=%d)\r\n",
              (int)ser_len, (unsigned)ser_seq-1, (unsigned)(ser_len - 4 - 1 - 2 - 2 /*approx header*/), fft_res.kept_n);
#endif

done:
    dbg_print("\r\n[PCA_SUMMARY] MSE=%.6f | TotVar=%.6f | Explained=%.2f%% | Samples=%d\r\n",
              mse, tot_var, (tot_var>1e-9f) ? (100.0f*(1.0f - mse / tot_var)) : 0.0f, sample_count);
    dbg_print("========================\r\n");

    /* reset batch */
    zero_buf();
    last_run_ms = now_ms;
    return 1;
}
/* accessor for serialized payload */
void pca_prune_get_serialized_payload(const uint8_t **ptr, uint16_t *len)
{
    if (ptr) *ptr = ser_buf;
    if (len) *len = ser_len;
}
