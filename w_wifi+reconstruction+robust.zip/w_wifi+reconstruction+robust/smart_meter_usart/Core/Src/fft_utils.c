/* -----------------------------------------------------------------------
 *  fft_utils.c  — Patch A (FINAL)
 *
 *  Replaces old fft_prune() with:
 *      int fft_prune(const float *scores, int len,
 *                    int max_keep_bins, float energy_threshold,
 *                    FFTPruneResult *res);
 *
 *  Features:
 *   - Correct FFT bin domain (FFT_NBINS = FFT_LEN/2 + 1)
 *   - Zero-pad input to FFT_LEN
 *   - Compute DFT (naive O(N^2) for portability)
 *   - Select top bins by magnitude/energy
 *   - Quantize (int16) using quant_scale
 *   - Return FFTPruneResult holding qre[], qim[], kept_idx[], kept_n, quant_scale, mse
 *   - No longer clamps against sample_count (bug fixed)
 *
 *  Fully compatible with Patch-A pca_prune.c
 * ----------------------------------------------------------------------- */

#include "fft_utils.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* -------------------------------------
 * Configuration
 * ------------------------------------- */
#ifndef FFT_LEN
#define FFT_LEN 64     /* power of 2; >= BATCH_M */
#endif

#ifndef MAX_KEEP_BINS
#define MAX_KEEP_BINS 8
#endif

#ifndef ENERGY_THRESHOLD
#define ENERGY_THRESHOLD 0.90f
#endif

/* Use half-spectrum (real FFT) */
#define USE_HALF_SPECTRUM 1

#if USE_HALF_SPECTRUM
    #define FFT_NBINS (FFT_LEN/2 + 1)   /* bins 0..32 for FFT_LEN=64 */
#else
    #define FFT_NBINS (FFT_LEN)
#endif

/* -------------------------------------
 * Internal DFT (naive but portable)
 * ------------------------------------- */
static void dft_real(const float *x, int N, float *re, float *im)
{
    for (int k = 0; k < N; ++k) {
        float acc_re = 0.0f;
        float acc_im = 0.0f;
        for (int n = 0; n < N; ++n) {
            float angle = -2.0f * M_PI * k * n / (float)N;
            acc_re += x[n] * cosf(angle);
            acc_im += x[n] * sinf(angle);
        }
        re[k] = acc_re;
        im[k] = acc_im;
    }
}

/* -------------------------------------
 * Select top-K bins by magnitude
 * ------------------------------------- */
typedef struct { float mag; int idx; } pair_t;

static int select_top_bins(const float *mag, int n_bins,
                           int max_keep, uint16_t *out_idx)
{
    if (n_bins <= 0) return 0;
    if (max_keep > n_bins) max_keep = n_bins;

    pair_t arr[FFT_NBINS];
    for (int i = 0; i < n_bins; ++i) {
        arr[i].mag = mag[i];
        arr[i].idx = i;
    }

    /* selection sort top K */
    for (int i = 0; i < max_keep; ++i) {
        int m = i;
        for (int j = i+1; j < n_bins; ++j)
            if (arr[j].mag > arr[m].mag)
                m = j;
        /* swap */
        if (m != i) {
            pair_t tmp = arr[i];
            arr[i] = arr[m];
            arr[m] = tmp;
        }
        out_idx[i] = (uint16_t)arr[i].idx;
    }

    return max_keep;
}

/* -------------------------------------
 * Main API: fft_prune()  (Patch-A)
 * ------------------------------------- */
int fft_prune(const float *scores, int len,
              int max_keep_bins, float energy_th,
              FFTPruneResult *res)
{
    if (!scores || !res) return -1;
    if (len <= 0 || len > FFT_LEN) return -2;
    if (max_keep_bins <= 0 || max_keep_bins > MAX_KEEP_BINS)
        max_keep_bins = MAX_KEEP_BINS;
    if (energy_th <= 0.0f || energy_th > 1.0f)
        energy_th = ENERGY_THRESHOLD;

    /* ------------------------------
     * 1) Zero-pad scores → x[FFT_LEN]
     * ------------------------------ */
    float x[FFT_LEN];
    for (int i = 0; i < FFT_LEN; ++i)
        x[i] = (i < len) ? scores[i] : 0.0f;

    /* ------------------------------
     * 2) DFT: x → re[], im[]
     * ------------------------------ */
    float re[FFT_LEN];
    float im[FFT_LEN];
    dft_real(x, FFT_LEN, re, im);

    /* ------------------------------
     * 3) Magnitude & energy
     * ------------------------------ */
    float mag[FFT_NBINS];
    float total_energy = 0.0f;

    for (int k = 0; k < FFT_NBINS; ++k) {
        float a = re[k];
        float b = im[k];
        float m2 = a*a + b*b;
        mag[k] = sqrtf(m2);
        total_energy += m2;
    }

    /* ------------------------------
     * 4) Select top bins by magnitude
     * ------------------------------ */
    uint16_t picked[MAX_KEEP_BINS];
    int picked_n = select_top_bins(mag, FFT_NBINS, max_keep_bins, picked);

    /* If energy threshold not reached, expand selection (simple method) */
    if (energy_th < 1.0f) {
        float cum = 0.0f;
        for (int i = 0; i < picked_n; ++i) {
            int k = picked[i];
            float a = re[k];
            float b = im[k];
            cum += (a*a + b*b);
        }

        if (total_energy > 0.0f && (cum / total_energy) < energy_th) {
            /* Try increasing K until threshold is met */
            for (int K = picked_n + 1; K <= max_keep_bins; ++K) {
                if (K > FFT_NBINS) break;

                uint16_t tmp_idx[MAX_KEEP_BINS];
                int ksel = select_top_bins(mag, FFT_NBINS, K, tmp_idx);

                float cum2 = 0.0f;
                for (int i = 0; i < ksel; ++i) {
                    int k = tmp_idx[i];
                    float a = re[k];
                    float b = im[k];
                    cum2 += (a*a + b*b);
                }
                if ((cum2 / total_energy) >= energy_th) {
                    picked_n = ksel;
                    for (int i = 0; i < ksel; ++i)
                        picked[i] = tmp_idx[i];
                    break;
                }
            }
        }
    }

    /* ------------------------------
     * 5) Quantization scale
     * ------------------------------ */
    float max_abs = 0.0f;
    for (int i = 0; i < picked_n; ++i) {
        int k = picked[i];
        float a = fabsf(re[k]);
        float b = fabsf(im[k]);
        if (a > max_abs) max_abs = a;
        if (b > max_abs) max_abs = b;
    }
    if (max_abs < 1e-12f) max_abs = 1.0f;
    float scale = max_abs / 32767.0f;

    /* ------------------------------
     * 6) Fill FFTPruneResult
     * ------------------------------ */
    res->kept_n = picked_n;
    res->quant_scale = scale;
    res->mse = 0.0f;

    for (int i = 0; i < picked_n; ++i) {
        int k = picked[i];

        /* domain check against FFT_NBINS */
        if (k < 0 || k >= FFT_NBINS) {
            fprintf(stderr, "[FFT][WARN] picked bin %d out of [0..%d), clamping\n",
                    k, FFT_NBINS-1);
            k = (k < 0) ? 0 : (FFT_NBINS - 1);
        }

        /* store index */
        res->kept_idx[i] = (uint16_t)k;

        /* quantize */
        float r = re[k] / scale;
        float imv = im[k] / scale;

        int32_t qr = (int32_t)roundf(r);
        int32_t qi = (int32_t)roundf(imv);

        if (qr > 32767) qr = 32767;
        if (qr < -32768) qr = -32768;
        if (qi > 32767) qi = 32767;
        if (qi < -32768) qi = -32768;

        res->qre[i] = (int16_t)qr;
        res->qim[i] = (int16_t)qi;
    }

    return 0;
}
